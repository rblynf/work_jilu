# require 'Sketchup.rb'
require 'find'
unless file_loaded?(__FILE__)
  face_toolbar = UI::Toolbar.new "QM"
  face_cmd = UI::Command.new("QM") {
    # 引入方法名
    path = File.join(File.dirname(__FILE__).force_encoding("utf-8"),'GroundHeatingCoil', 'Ruby')
    Find.find(path) { |filename| load filename if File.file?(filename) }
    load File.join(File.dirname(__FILE__), "/GroundHeatingCoil/GroundHeatingPipe.rb")
    GroundHeatingPipe::Mycoil.new
    GroundHeatingPipe::Mycoil.show
  }
  face_cmd.small_icon="/GroundHeatingCoil/tubiao.png"
  face_cmd.large_icon="/GroundHeatingCoil/tubiao.png"
  face_toolbar.add_item face_cmd
  face_toolbar.show
end
file_loaded(__FILE__)