# require 'common_ly/chartComponents.rb'

include Math
class WaiqiangLine
	##################### Pipe_line.new.array_type_line
	#直列型管道
	#入参：sx管道入口房间角x坐标  sy管道入口房间角y坐标  long房间长   wide房间宽 
	#     pipeSpace1外墙管道间距  pipeSpace2内管道间距  forNum 外墙线循环次数               
	#																[200.mm,500.mm,0]  [2000.mm,2900.mm,0]	[5200.mm,500.mm,0] [3400.mm,-1900.mm,0]					
	##################################
		
	def run(safe_distance = 150.mm, outer_area_spacing = 225.mm, inner_area_spacing = 195.mm, special_size = 4, vec1=[3,4,0], vec2=[4,-3,0], line_lists=[[[5200.mm,500.mm,0],[3400.mm,-1900.mm,0]],[[],[]],[[],[]],[[],[]]], cornerRadius = 150.mm, limit_length = 100000.mm, origin = [200.mm,500.mm,0], long = 4000.mm, wide = 3000.mm)
		sx = origin.x
		sy = origin.y		
		vec1_length = Math.sqrt(vec1[0]*vec1[0] + vec1[1]*vec1[1])
		vec2_length = Math.sqrt(vec2[0]*vec2[0] + vec2[1]*vec2[1])
		#vec1方向上每1个单位长度对应x、y轴方向上的长度
		vec1_xlength = (vec1[0]/vec1_length)*1
		vec1_ylength = (vec1[1]/vec1_length)*1
		
		#vec2方向上每1个单位长度对应x、y轴方向上的长度
		vec2_xlength = (vec2[0]/vec2_length)*1
		vec2_ylength = (vec2[1]/vec2_length)*1
		
		#房间四端点的坐标
		#靠近起点的
		roomPoint0 = [sx, sy, 0]
		#往vec1方向的
		roomPoint1 = [sx + vec1_xlength*wide, sy + vec1_ylength*wide, 0]
		#再往vec2方向的
		roomPoint2 = [sx + vec1_xlength*wide + vec2_xlength*long, sy + vec1_ylength*wide + vec2_ylength*long, 0]
		#往vec1反方向的
		roomPoint3 = [sx + vec2_xlength*long, sy + vec2_ylength*long, 0] 	
		# p "@@"*10
		# p roomPoint1[0].to_mm
		# p roomPoint1[1].to_mm
		# p roomPoint2[0].to_mm
		# p roomPoint2[1].to_mm
		# p roomPoint3[0].to_mm
		# p roomPoint3[1].to_mm
		#墙距
		distanceFromWall = safe_distance
		pipeSpace1 = outer_area_spacing
		pipeSpace2 = inner_area_spacing
		forNum = special_size
		
		#分析外墙的面数及位置
		waiQiangNum = line_lists.size
		
		#先定义各类型端点数组，以便存放管理端点
		sLineSegments = []  #直线段端点数组
		if waiQiangNum == 1
			w1Flag = true
			#判断是哪一面
			if line_lists[0][0] == roomPoint0		
				wType = 0 #类型标志
				#内循环次数
				inCount = ((long - distanceFromWall*2 - pipeSpace1*(forNum - 1))/pipeSpace2).to_i
				inCount -=  1  if (inCount + forNum)%2 != 0 #确保管道正常返回
					 
				remainLong = long - distanceFromWall*2 - pipeSpace1*(forNum-1) - pipeSpace2*inCount 
			elsif line_lists[0][0] == roomPoint1
				wType = 1 #类型标志
				#内循环次数
				inCount = ((wide - distanceFromWall*2 - pipeSpace1*(forNum - 1))/pipeSpace2).to_i
				remainLong = wide - distanceFromWall*2 - pipeSpace1*(forNum-1) - pipeSpace2*inCount 
			elsif line_lists[0][0] == roomPoint2
				wType = 2
				#内循环次数
				inCount = ((long - distanceFromWall*2 - pipeSpace1*(forNum - 1))/pipeSpace2).to_i
				inCount -=  1 if (inCount + forNum)%2 != 0 #确保管道正常返回
					  
				remainLong = long - distanceFromWall*2 - pipeSpace1*(forNum-1) - pipeSpace2*inCount 
			elsif line_lists[0][0] == roomPoint3
				wType = 3
				inCount = ((wide - distanceFromWall*2 - pipeSpace1*(forNum-1))/pipeSpace2).to_i
				inCount = inCount - 1  if (inCount + forNum)%2 != 0 
					 
				remainLong = wide - distanceFromWall*2 - pipeSpace1*(forNum-1) - pipeSpace2*inCount 
			else
				w1Flag = false  #坐标错误
			end
			if w1Flag 
				sLineSegments_2 = []
				sLineSegments_2 << common_operate(wType,remainLong,forNum,sx,sy,vec1_xlength,vec1_ylength,vec2_xlength,vec2_ylength,pipeSpace1,pipeSpace2,long,wide,distanceFromWall,inCount,cornerRadius)
			
				pipeSpace2 = pipeSpace2 + remainLong/inCount
				remainLong = 0
				sLineSegments_2 << common_operate(wType,remainLong,forNum,sx,sy,vec1_xlength,vec1_ylength,vec2_xlength,vec2_ylength,pipeSpace1,pipeSpace2,long,wide,distanceFromWall,inCount,cornerRadius)
			end
		#两面外墙
		elsif waiQiangNum == 2
			w2Flag = true
			if line_lists[0][0] == roomPoint0
				wType = 4
				if forNum%2 == 0
					inCount = ((long - distanceFromWall*2 - pipeSpace1*(forNum-1))/pipeSpace2).to_i 
					inCount -= 1 if inCount%2 != 0
						
					remainLong = long - distanceFromWall*2 - pipeSpace1*(forNum-1) - pipeSpace2*inCount
				else
					inCount = ((wide - distanceFromWall*2 - pipeSpace1*(forNum-1))/pipeSpace2).to_i 
					inCount -= 1 if inCount%2 == 0
						
					remainWide = wide - distanceFromWall*2 - pipeSpace1*(forNum-1) - pipeSpace2*inCount
					remainLong = remainWide
				end 
			elsif line_lists[0][0] == roomPoint1
				wType = 5
				if forNum%2 != 0
					inCount = ((long - distanceFromWall*2 - pipeSpace1*(forNum-1))/pipeSpace2).to_i 
					inCount -= 1 if inCount%2 == 0
						
					remainLong = long - distanceFromWall*2 - pipeSpace1*(forNum-1) - pipeSpace2*inCount
				else
					inCount = ((wide - distanceFromWall*2 - pipeSpace1*(forNum-1))/pipeSpace2).to_i
					inCount -= 1 if inCount%2 != 0
						
					remainWide = wide - distanceFromWall*2 - pipeSpace1*(forNum-1) - pipeSpace2*inCount
					remainLong = remainWide
				end
			elsif line_lists[0][0] == roomPoint2
				wType = 6
				if forNum%2 == 0
					inCount = ((long - distanceFromWall*2 - pipeSpace1*(forNum-1))/pipeSpace2).to_i 
					inCount -= 1 if inCount%2 != 0
						
					remainLong = long - distanceFromWall*2 - pipeSpace1*(forNum-1) - pipeSpace2*inCount
				else
					inCount = ((wide - distanceFromWall*2 - pipeSpace1*(forNum-1))/pipeSpace2).to_i
					inCount -= 1 if inCount%2 == 0
						
					remainWide = wide - distanceFromWall*2 - pipeSpace1*(forNum-1) - pipeSpace2*inCount
					remainLong = remainWide
				end
			else
				w2Flag = false #坐标有误
			end
			if w2Flag
				sLineSegments_2 = []
				sLineSegments_2 << common_operate(wType,remainLong,forNum,sx,sy,vec1_xlength,vec1_ylength,vec2_xlength,vec2_ylength,pipeSpace1,pipeSpace2,long,wide,distanceFromWall,inCount,cornerRadius)
			
				pipeSpace2 = pipeSpace2 + remainLong/inCount
				remainLong = 0
				sLineSegments_2 << common_operate(wType,remainLong,forNum,sx,sy,vec1_xlength,vec1_ylength,vec2_xlength,vec2_ylength,pipeSpace1,pipeSpace2,long,wide,distanceFromWall,inCount,cornerRadius)
			end
		#三面外墙
		elsif waiQiangNum == 3
			w3Flag = true
			#判断是哪一面
			if line_lists[0][0] == roomPoint0	
				wType = 7
				inCount = ((long - distanceFromWall*2 - pipeSpace1*2*(forNum-1))/pipeSpace2).to_i
				inCount -=  1 if inCount%2 == 0  #奇数个才能返回
					  
				remainLong = long - distanceFromWall*2 - pipeSpace1*2*(forNum-1) - pipeSpace2*inCount
				
			elsif line_lists[0][0] == roomPoint1
				wType = 8
				#墙距				
				inCount = ((wide - distanceFromWall*2 - pipeSpace1*2*(forNum-1))/pipeSpace2).to_i
				inCount -=  1  if inCount%2 == 0 
					
				remainLong = wide - distanceFromWall*2 - pipeSpace1*2*(forNum-1) - pipeSpace2*inCount
			else
				w3Flag =  false #坐标有误
			end
			if w3Flag
				sLineSegments_2 = []
				sLineSegments_2 << common_operate(wType,remainLong,forNum,sx,sy,vec1_xlength,vec1_ylength,vec2_xlength,vec2_ylength,pipeSpace1,pipeSpace2,long,wide,distanceFromWall,inCount,cornerRadius)
				#均分管间距
				pipeSpace2 = pipeSpace2 + remainLong/inCount
				remainLong = 0
				sLineSegments_2 << common_operate(wType,remainLong,forNum,sx,sy,vec1_xlength,vec1_ylength,vec2_xlength,vec2_ylength,pipeSpace1,pipeSpace2,long,wide,distanceFromWall,inCount,cornerRadius)
			end 
		
		#四面外墙
		elsif waiQiangNum == 4
			wType = 9  #外间距为内间距的3倍 (往复型)
			
			#管道间距数
			inCount = ((wide - distanceFromWall*2)/pipeSpace2).to_i
			if inCount%4 == 0 || inCount%4 == 2
				inCount -= 1
			end 
			remainLong = wide - distanceFromWall*2 - pipeSpace2*inCount
						
			sLineSegments_2 = []
			# sLineSegments_2 << common_operate(wType,remainLong,forNum,sx,sy,vec1_xlength,vec1_ylength,vec2_xlength,vec2_ylength,pipeSpace1,pipeSpace2,long,wide,distanceFromWall,inCount,cornerRadius)
			#均分管间距
			pipeSpace2 = pipeSpace2 + remainLong/inCount
			remainLong = 0
			sLineSegments_2 << common_operate(wType,remainLong,forNum,sx,sy,vec1_xlength,vec1_ylength,vec2_xlength,vec2_ylength,pipeSpace1,pipeSpace2,long,wide,distanceFromWall,inCount,cornerRadius)
						
		end

		
		#画线
		# draw_line(sLineSegments_2[0])
	end
	
	def common_operate(wType,remainLong,forNum,sx,sy,vec1_xlength,vec1_ylength,vec2_xlength,vec2_ylength,pipeSpace1,pipeSpace2,long,wide,distanceFromWall,inCount,cornerRadius)
		sLineSegments = []
		case wType
		when 0
			# 1 管道入口
			sLineSegments << [sx + vec2_xlength*distanceFromWall, sy + vec2_ylength*distanceFromWall, 0]
			#2 开始外循环
			(0...forNum).each{|i|
				if i%2 == 0
					if i == 0
						sLineSegments << [sx + vec2_xlength*distanceFromWall + vec1_xlength*(wide - distanceFromWall - pipeSpace1/2), sy + vec2_ylength*distanceFromWall + vec1_ylength*(wide - distanceFromWall - pipeSpace1/2), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1/2), 0]
					end
				else
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1/2), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2), 0]
				end
			}
			#开始内循环
			if forNum%2 == 0
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1)) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1)) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), 0]
				(0...inCount).each{|i|
					if i%2 == 0 
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), 0]
					end
				}
			else
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1)) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1)) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2), 0]
				(0...inCount).each{|i|
					if i%2 == 0 
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2), 0]
					end
				}
			end
			#3出口,开始时已确保(forNum + inCount)%2 == 0
			sLineSegments.pop(4)
			
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2 - remainLong/2) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2 - remainLong/2) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), 0]
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2 - remainLong/2) + vec1_xlength*(wide - distanceFromWall - (remainLong + pipeSpace2)/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2 - remainLong/2) + vec1_ylength*(wide - distanceFromWall - (remainLong + pipeSpace2)/2), 0]

			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(wide - distanceFromWall - (remainLong + pipeSpace2)/2), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(wide - distanceFromWall - (remainLong + pipeSpace2)/2), 0]
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
			
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*distanceFromWall, sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*distanceFromWall, 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + distanceFromWall/4) + vec1_xlength*distanceFromWall, sy + vec2_ylength*(distanceFromWall + pipeSpace2 + distanceFromWall/4) + vec1_ylength*distanceFromWall, 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2) + vec1_xlength*(distanceFromWall - distanceFromWall/4), sy + vec2_ylength*(distanceFromWall + pipeSpace2) + vec1_ylength*(distanceFromWall - distanceFromWall/4), 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2), sy + vec2_ylength*(distanceFromWall + pipeSpace2), 0]

		when 1
			# 1 管道入口
			sLineSegments << [sx + vec2_xlength*distanceFromWall, sy + vec2_ylength*distanceFromWall, 0]
			sLineSegments << [sx + vec2_xlength*distanceFromWall + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*distanceFromWall + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
			#绕外墙循环
			(0...forNum).each{|i|
				if i%2 == 0
					if i == 0
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1/2) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1/2) + vec1_ylength*(wide - distanceFromWall), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]							
					end
				else
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
				end
			}
			#开始内循环
			if forNum % 2 == 0
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1)), 0]
				(0...inCount).each{|i|
					if i%2 == 0 
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), 0]							
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), 0]
					end
				}
			else
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1)), 0]
				(0...inCount).each{|i|
					if i%2 == 0 
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i), 0]
					end
				}
			end
			# 3 出口 
			if (inCount + forNum)%2 == 0
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2*inCount), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2*inCount), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2*inCount - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2*inCount - cornerRadius), 0]
			else
				#剩余位置不足，去掉一条管道
				sLineSegments.pop(3)
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2*(inCount - 1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2*(inCount - 1)), 0]
			
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2*(inCount-1) - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2*(inCount-1) - cornerRadius), 0]
			end 
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2), sy + vec2_ylength*(distanceFromWall + pipeSpace2), 0]
			
		when 2 
			sLineSegments = []
			#1。管道入口部分
			sLineSegments <<  [sx + vec2_xlength*distanceFromWall, sy + vec2_ylength*distanceFromWall, 0]
			sLineSegments << [sx + vec2_xlength*distanceFromWall + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*distanceFromWall + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
			#2循环部分
			#绕外墙循环
			(0...forNum).each{|i|
				if i%2 == 0
					if i == 0
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + pipeSpace1/2), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + pipeSpace1/2), 0]
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace1/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace1/2), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(distanceFromWall + pipeSpace1/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(distanceFromWall + pipeSpace1/2), 0]
					end
				else
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(distanceFromWall + pipeSpace1/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(distanceFromWall + pipeSpace1/2), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace1/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace1/2), 0]
				end
			}
			#开始内循环
			if forNum%2 == 0
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum - 1)) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum - 1)) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), 0]
				(0...(inCount-1)).each{|i|
					if i%2 == 0 
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]					
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), 0]							
					end
				}
			else
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum - 1)) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum - 1)) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
				(0...(inCount-1)).each{|i|
					if i%2 == 0 
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), 0]					
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
					end
				}

			end	
			#3出口 前面已确保（forNum+inCount）%2 == 0 
			sLineSegments.pop(4)
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + remainLong*2/3 + pipeSpace2) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + remainLong*2/3 + pipeSpace2) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + remainLong*2/3 + pipeSpace2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - (pipeSpace2 + remainLong/3)/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + remainLong*2/3 + pipeSpace2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - (pipeSpace2 + remainLong/3)/2), 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + remainLong/3) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - (pipeSpace2 + remainLong/3)/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + remainLong/3) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - (pipeSpace2 + remainLong/3)/2), 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + remainLong/3), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + remainLong/3), 0]
			
		when 3
			sLineSegments = []
			#1.管道入口部分
			sLineSegments << [sx + vec2_xlength*distanceFromWall, sy + vec2_ylength*distanceFromWall, 0]
			sLineSegments << [sx + vec2_xlength*distanceFromWall + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*distanceFromWall + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*distanceFromWall, sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*distanceFromWall, 0]

			# 外循环
			(0...forNum).each{|i|
				if i%2 == 0
					if i == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace1/2) + vec1_xlength*distanceFromWall, sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace1/2) + vec1_ylength*distanceFromWall, 0]
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace1/2) + vec1_xlength*(distanceFromWall + pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace1/2) + vec1_ylength*(distanceFromWall + pipeSpace1*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace1/2) + vec1_xlength*(distanceFromWall + pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace1/2) + vec1_ylength*(distanceFromWall + pipeSpace1*i), 0]
					end
				else
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace1/2) + vec1_xlength*(distanceFromWall + pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace1/2) + vec1_ylength*(distanceFromWall + pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace1/2) + vec1_xlength*(distanceFromWall + pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace1/2) + vec1_ylength*(distanceFromWall + pipeSpace1*i), 0]
				end 
			}
			#内循环
			if forNum%2 == 0
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum - 1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum - 1)), 0]
				(0...(inCount-1)).each{|i|
					if i%2 == 0
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), 0]
					end 
				}
			else
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum - 1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum - 1)), 0]
				(0...(inCount-1)).each{|i|
					if i%2 == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), 0]
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum - 1) + pipeSpace2 + pipeSpace2*i), 0]
					end 
				}
			end
			#3出口
			sLineSegments.pop(5)
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2*3 - remainLong), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2*3 - remainLong), 0]
			
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2*2 - remainLong/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2*2 - remainLong/2), 0]
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - (pipeSpace2+remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2*2 - remainLong/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - (pipeSpace2+remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2*2 - remainLong/2), 0]
			
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - (pipeSpace2+remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - (pipeSpace2+remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2), 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_xlength*(wide - distanceFromWall - pipeSpace2), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_ylength*(wide - distanceFromWall - pipeSpace2), 0]

			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2 - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2 - cornerRadius), 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2), sy + vec2_ylength*(distanceFromWall + pipeSpace2), 0]	
		
		when 4
			sLineSegments = []
			#外循环
			(0...forNum).each{|i|
				if i%2 == 0
					if i == 0
						#管道入口
						sLineSegments << [sx + vec2_xlength*distanceFromWall, sy + vec2_ylength*distanceFromWall, 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2), 0]
					end
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius + pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + cornerRadius + pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
				else
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius + pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + cornerRadius + pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2), 0]
				end
			}
			#内循环
			if forNum%2 == 0
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1)) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1)) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), 0]
				(0...inCount).each{|i|
					if i%2 == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), 0]
					end
				}
				
				#调距
				sLineSegments.pop(5)
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - (pipeSpace2*2+remainLong)) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2*2+remainLong)/4), sy + vec2_ylength*(long - distanceFromWall - (pipeSpace2*2+remainLong)) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2*2+remainLong)/4), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - (pipeSpace2*2+remainLong)/2) + vec1_xlength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2*2+remainLong)/4), sy + vec2_ylength*(long - distanceFromWall - (pipeSpace2*2+remainLong)/2) + vec1_ylength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2*2+remainLong)/4), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - (pipeSpace2*2+remainLong)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2*2+remainLong)/4), sy + vec2_ylength*(long - distanceFromWall - (pipeSpace2*2+remainLong)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2*2+remainLong)/4), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2*2+remainLong)/4), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2*2+remainLong)/4), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
				#出口
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*(distanceFromWall), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1 + distanceFromWall/4) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(distanceFromWall + pipeSpace1 + distanceFromWall/4) + vec1_ylength*(distanceFromWall), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1) + vec1_xlength*(distanceFromWall - distanceFromWall/4), sy + vec2_ylength*(distanceFromWall + pipeSpace1) + vec1_ylength*(distanceFromWall - distanceFromWall/4), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1), sy + vec2_ylength*(distanceFromWall + pipeSpace1), 0]
			else
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1)), 0]
				(0...inCount).each{|i|
					if i%2 == 0
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]
					end
				}
				
				#调距
				sLineSegments.pop(5)
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + (pipeSpace2 + remainLong/2)/2) + vec1_xlength*(distanceFromWall + pipeSpace2*2 + remainLong), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_ylength*(distanceFromWall + pipeSpace2*2 + remainLong), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + (pipeSpace2 + remainLong/2)/2) + vec1_xlength*(distanceFromWall + pipeSpace2 + remainLong/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_ylength*(distanceFromWall + pipeSpace2 + remainLong/2), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - (pipeSpace2 + remainLong/2)/2) + vec1_xlength*(distanceFromWall + pipeSpace2 + remainLong/2), sy + vec2_ylength*(long - distanceFromWall - (pipeSpace2 + remainLong/2)/2) + vec1_ylength*(distanceFromWall + pipeSpace2 + remainLong/2), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - (pipeSpace2 + remainLong/2)/2) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - (pipeSpace2 + remainLong/2)/2) + vec1_ylength*(distanceFromWall), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + distanceFromWall/4) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + distanceFromWall/4) + vec1_ylength*(distanceFromWall), 0]

				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2) + vec1_xlength*(distanceFromWall - distanceFromWall/4), sy + vec2_ylength*(distanceFromWall + pipeSpace2) + vec1_ylength*(distanceFromWall - distanceFromWall/4), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2), sy + vec2_ylength*(distanceFromWall + pipeSpace2), 0]
			end
			
		when 5 
			sLineSegments = []
			#入口
			sLineSegments << [sx + vec2_xlength*distanceFromWall, sy + vec2_ylength*distanceFromWall, 0]
			sLineSegments << [sx + vec2_xlength*distanceFromWall + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*distanceFromWall + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
			#外循环
			(0...forNum).each{|i|
				if i%2 == 0
					if i == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
					end 
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(distanceFromWall + pipeSpace1/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(distanceFromWall + pipeSpace1/2), 0]
				else
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(distanceFromWall + pipeSpace1/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(distanceFromWall + pipeSpace1/2), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
				end 
			}
			#内循环 
			if forNum%2 != 0
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1)) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1)) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
				(0...(inCount-1)).each{|i|
					if i%2 == 0
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), 0]
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
					end
				}
				#调距
				sLineSegments.pop(5)
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2*3 + remainLong) + vec1_xlength*(distanceFromWall + (pipeSpace2+remainLong/3)/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2*3 + remainLong) + vec1_ylength*(distanceFromWall + (pipeSpace2+remainLong/3)/2), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2*2 + remainLong*2/3) + vec1_xlength*(distanceFromWall + (pipeSpace2+remainLong/3)/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2*2 + remainLong*2/3) + vec1_ylength*(distanceFromWall + (pipeSpace2+remainLong/3)/2), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2*2 + remainLong*2/3) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2*2 + remainLong*2/3) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + remainLong/3) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + remainLong/3) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), 0]
				#出口
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + remainLong/3), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + remainLong/3), 0]
			else
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1)), 0]
				(0...inCount).each{|i|
					if i%2 == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]
					end
				}
				#调距
				sLineSegments.pop(5)
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_xlength*(distanceFromWall + pipeSpace2*2 + remainLong), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_ylength*(distanceFromWall + pipeSpace2*2 + remainLong), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_xlength*(distanceFromWall + pipeSpace2 + remainLong/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_ylength*(distanceFromWall + pipeSpace2 + remainLong/2), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2+remainLong/2)/2) + vec1_xlength*(distanceFromWall + pipeSpace2 + remainLong/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2+remainLong/2)/2) + vec1_ylength*(distanceFromWall + pipeSpace2 + remainLong/2), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2+remainLong/2)/2) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2+remainLong/2)/2) + vec1_ylength*(distanceFromWall), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + distanceFromWall/4) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + distanceFromWall/4) + vec1_ylength*(distanceFromWall), 0]

				#出口
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2) + vec1_xlength*(distanceFromWall - distanceFromWall/4), sy + vec2_ylength*(distanceFromWall + pipeSpace2) + vec1_ylength*(distanceFromWall - distanceFromWall/4), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2), sy + vec2_ylength*(distanceFromWall + pipeSpace2), 0]
			end 
			
		when 6 
			sLineSegments = []
			#入口
			sLineSegments << [sx + vec2_xlength*distanceFromWall, sy + vec2_ylength*distanceFromWall, 0]
			sLineSegments << [sx + vec2_xlength*distanceFromWall + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*distanceFromWall + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
			sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
			#外循环
			(0...forNum).each{|i|
				if i%2 == 0
					if i == 0
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace1/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace1/2), 0]
					end
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(distanceFromWall + cornerRadius + pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(distanceFromWall + cornerRadius + pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_xlength*(distanceFromWall + pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_ylength*(distanceFromWall + pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace1/2) + vec1_xlength*(distanceFromWall + pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace1/2) + vec1_ylength*(distanceFromWall + pipeSpace1*i), 0]
				else
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace1/2) + vec1_xlength*(distanceFromWall + pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace1/2) + vec1_ylength*(distanceFromWall + pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_xlength*(distanceFromWall + pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_ylength*(distanceFromWall + pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(distanceFromWall + cornerRadius + pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(distanceFromWall + cornerRadius + pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace1/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace1/2), 0]
				end
			}
			#内循环
			if forNum%2 == 0
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1)) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1)) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), 0]
				(0...(inCount-1)).each{|i|
					if i%2 == 0
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + pipeSpace2/2), 0]
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - pipeSpace2/2), 0]
					end
				
				}
				#调距
				sLineSegments.pop(5)
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2*2 + remainLong) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + (pipeSpace2+remainLong/2)/2 + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2*2 + remainLong) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2 + remainLong/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + (pipeSpace2+remainLong/2)/2 + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2 + remainLong/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2 + remainLong/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - (pipeSpace2+remainLong/2)/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2 + remainLong/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - (pipeSpace2+remainLong/2)/2), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2/2 - (pipeSpace2+remainLong/2)/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2/2 - (pipeSpace2+remainLong/2)/2), 0]
				#出口
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2), sy + vec2_ylength*(distanceFromWall + pipeSpace2), 0]
			else
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1)), 0]
				(0...(inCount-1)).each{|i|
					if i%2 == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), 0]
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), 0]
					end
				}
				#调距
				sLineSegments.pop(5)
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + (pipeSpace2+remainLong/3)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2*3 - remainLong), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + (pipeSpace2+remainLong/3)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2*3 - remainLong), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + (pipeSpace2+remainLong/3)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2*2 - remainLong*2/3), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + (pipeSpace2+remainLong/3)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2*2 - remainLong*2/3), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2+remainLong/3)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2*2 - remainLong*2/3), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2+remainLong/3)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2*2 - remainLong*2/3), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2+remainLong/3)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2 - remainLong/3), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2+remainLong/3)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2 - remainLong/3), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_xlength*(wide - distanceFromWall - pipeSpace2 - remainLong/3), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_ylength*(wide - distanceFromWall - pipeSpace2 - remainLong/3), 0]
				#出口
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2 - remainLong/3 - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2 - remainLong/3 - cornerRadius), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2), sy + vec2_ylength*(distanceFromWall + pipeSpace2), 0]
			end
		
		when 7 
			#1.管道入口部分及外墙循环端点坐标
			sLineSegments << [sx + vec2_xlength*distanceFromWall, sy + vec2_ylength*distanceFromWall, 0]
			(0...forNum).each{|i|
				if i%2 == 0
					if i == 0
						sLineSegments << [sx + vec2_xlength*distanceFromWall + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*distanceFromWall + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*i) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace1*i) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius + pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + cornerRadius + pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
					end 
				else
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius + pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + cornerRadius + pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*i) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace1*i) + vec1_ylength*(distanceFromWall + cornerRadius), 0]	
				end
				}
			
			# 2内循环
			if forNum%2 != 0
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1)) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1)) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
				(0...(inCount-1)).each{|i|
					if i%2 == 0 
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2/2 - pipeSpace2/2), 0]
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2/2 - pipeSpace2/2), 0]
						if i != inCount - 2
							sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
						else
							sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-1)) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-1)) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
						end
					end
				}
				#修改后两段的间距
				sLineSegments.pop(3)
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*(inCount-3)) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2/2 - (pipeSpace2 + remainLong/2)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2 - pipeSpace2*(inCount-3)) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2/2 - (pipeSpace2 + remainLong/2)), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + remainLong/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2/2 - (pipeSpace2 + remainLong/2)), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + remainLong/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum - 1) - pipeSpace2/2 - (pipeSpace2 + remainLong/2)), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + remainLong/2) + vec1_xlength*(distanceFromWall/2 + cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + remainLong/2) + vec1_ylength*(distanceFromWall/2 + cornerRadius), 0]
				#3出口 
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + remainLong/2 - cornerRadius) + vec1_xlength*(distanceFromWall/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + remainLong/2 - cornerRadius) + vec1_ylength*(distanceFromWall/2), 0]
			else
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1)) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1)) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
				(0...(inCount-1)).each{|i|
					if i%2 == 0 
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2), 0]
						if i != inCount - 2
							sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(distanceFromWall + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(distanceFromWall + pipeSpace2/2), 0]
						else
							sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_xlength*(distanceFromWall/2 + pipeSpace2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*i) + vec1_ylength*(distanceFromWall/2 + pipeSpace2/2), 0]
						end
					end
				}
				#修改后两段的间距
				sLineSegments.pop(3)
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*(inCount-3)) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2 + remainLong/2)/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*(inCount-3)) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2 + remainLong/2)/2), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*(inCount-3) + (pipeSpace2 + remainLong/2)) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2 + remainLong/2)/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*(inCount-3) + (pipeSpace2 + remainLong/2)) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2 + remainLong/2)/2), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*(inCount-3) + (pipeSpace2 + remainLong/2)) + vec1_xlength*(distanceFromWall/2 + cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*(inCount-3) + (pipeSpace2 + remainLong/2)) + vec1_ylength*(distanceFromWall/2 + cornerRadius), 0]
				
				#3出口
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*(inCount-3) + (pipeSpace2 + remainLong/2) - cornerRadius) + vec1_xlength*(distanceFromWall/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2 + pipeSpace2*(inCount-3)+ (pipeSpace2 + remainLong/2) - cornerRadius) + vec1_ylength*(distanceFromWall/2), 0]
			end
			#3出口
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1/2 + distanceFromWall/2) + vec1_xlength*(distanceFromWall/2), sy + vec2_ylength*(distanceFromWall + pipeSpace1/2 + distanceFromWall/2) + vec1_ylength*(distanceFromWall/2), 0]				
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1/2 + distanceFromWall/4) + vec1_xlength*(distanceFromWall/4), sy + vec2_ylength*(distanceFromWall + pipeSpace1/2 + distanceFromWall/4) + vec1_ylength*(distanceFromWall/4), 0]				
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace1/2 + distanceFromWall/4), sy + vec2_ylength*(distanceFromWall + pipeSpace1/2 + distanceFromWall/4), 0]				
		when 8 
			remainWide = remainLong
			#1.管道入口部分
			sLineSegments << [sx + vec2_xlength*distanceFromWall, sy + vec2_ylength*distanceFromWall, 0]
			sLineSegments << [sx + vec2_xlength*distanceFromWall + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*distanceFromWall + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
			# 外墙循环
			(0...forNum).each{|i|
				if i%2 == 0
					if i == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]	
					end
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(distanceFromWall + cornerRadius + pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(distanceFromWall + cornerRadius + pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_xlength*(distanceFromWall + pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_ylength*(distanceFromWall + pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*i), 0]
				else
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_xlength*(distanceFromWall + pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_ylength*(distanceFromWall + pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(distanceFromWall + cornerRadius + pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(distanceFromWall + cornerRadius + pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius - pipeSpace1*i) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1/2 - pipeSpace1*i) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace1/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*i), 0]	
				end
			}
			# 2内管线的管道间距个数
			if forNum%2 == 0
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1)), 0]	
				(0...(inCount-1)).each{|i|
					if i%2 == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]	
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]	
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]	
						if i == inCount-2
							sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2 + cornerRadius) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2 + cornerRadius) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]	
						else
							sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(i+1)), 0]	
						end
					end
				}
				#调距
				sLineSegments.pop(5)
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2 + remainWide/3)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-3)), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2 + remainWide/3)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-3)), 0]	
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2 + remainWide/3)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-2) - remainWide/3), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2 + remainWide/3)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-2) - remainWide/3), 0]	
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2 + remainWide/3)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-2) - remainWide/3), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2 + remainWide/3)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-2) - remainWide/3), 0]	
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2 + remainWide/3)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-1) - remainWide*2/3), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2 + remainWide/3)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-1) - remainWide*2/3), 0]	
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-1) - remainWide*2/3), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-1) - remainWide*2/3), 0]	
				# 出口
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-1) - remainWide*2/3 - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2*(inCount-1) - remainWide*2/3 - cornerRadius), 0]	
			else
				sLineSegments.pop()
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1)), 0]	
				(0...(inCount-1)).each{|i|
					if i%2 == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), 0]	
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), 0]	
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), 0]	
						if i == inCount-2
							sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), 0]	
						else
							sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace1*(forNum-1) + pipeSpace2*(i+1)), 0]	
						end
					end
				}
				#调距
				sLineSegments.pop(5)
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + (pipeSpace2 + remainWide/3)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - (pipeSpace2 + remainWide/3)*3), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + (pipeSpace2 + remainWide/3)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - (pipeSpace2 + remainWide/3)*3), 0]	
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + (pipeSpace2 + remainWide/3)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - (pipeSpace2 + remainWide/3)*2), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + pipeSpace2/2 + (pipeSpace2 + remainWide/3)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - (pipeSpace2 + remainWide/3)*2), 0]	
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2 + remainWide/3)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - (pipeSpace2 + remainWide/3)*2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2 + remainWide/3)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - (pipeSpace2 + remainWide/3)*2), 0]	
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2 + remainWide/3)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - (pipeSpace2 + remainWide/3)), sy + vec2_ylength*(long - distanceFromWall - pipeSpace1*(forNum-1) - pipeSpace2/2 - (pipeSpace2 + remainWide/3)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - (pipeSpace2 + remainWide/3)), 0]	
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - (pipeSpace2 + remainWide/3)), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + cornerRadius) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - (pipeSpace2 + remainWide/3)), 0]	
				# 出口
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2) + vec1_xlength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - (pipeSpace2 + remainWide/3) - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace2) + vec1_ylength*(wide - distanceFromWall - pipeSpace1*(forNum-1) - (pipeSpace2 + remainWide/3) - cornerRadius), 0]	
			end
			# 出口
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2), 0]	
		when 9
			reciprocateType = 0 #标志
			if inCount%4 == 1
				reciprocateType = 1   #出入口方向与返回口方向不一致
			elsif inCount%4 == 3
				reciprocateType = 2
			elsif inCount%4 == 2 #余2
				reciprocateType = 1
			else #整除时
				reciprocateType = 2
			end

			sLineSegments = [] #直线段端点数组
			#入口
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2), sy + vec2_ylength*(distanceFromWall + pipeSpace2), 0]
			sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2) + vec1_xlength*(distanceFromWall - distanceFromWall/4), sy + vec2_ylength*(distanceFromWall + pipeSpace2) + vec1_ylength*(distanceFromWall - distanceFromWall/4), 0]
			if reciprocateType == 1
				#往的循环部分
				(0...(inCount/4).to_i).each { |i|
					if i == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + distanceFromWall/4) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + distanceFromWall/4) + vec1_ylength*(distanceFromWall), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace2*4*i), 0]
					end
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(distanceFromWall + pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*(distanceFromWall + pipeSpace2*4*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + cornerRadius + pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + cornerRadius + pipeSpace2*4*i), 0]
					
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + pipeSpace2*3 - cornerRadius + pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + pipeSpace2*3 - cornerRadius + pipeSpace2*4*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(distanceFromWall + pipeSpace2*3 + pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall -cornerRadius) + vec1_ylength*(distanceFromWall + pipeSpace2*3 + pipeSpace2*4*i), 0]
					
					if i != (inCount/4).to_i - 1
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace2*3 + pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace2*3 + pipeSpace2*4*i), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_xlength*(distanceFromWall + pipeSpace2*3 + pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_ylength*(distanceFromWall + pipeSpace2*3 + pipeSpace2*4*i), 0]
					end
				}
				#往-复中间
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2 - remainLong/2), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + (pipeSpace2+remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2 - remainLong/2), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - (pipeSpace2+remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace2 - remainLong/2), sy + vec2_ylength*(long - distanceFromWall - (pipeSpace2+remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace2 - remainLong/2), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - (pipeSpace2+remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - (pipeSpace2+remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall) + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*(distanceFromWall) + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
				#复的循环
				(0...(inCount/4).to_i).each { |i|
					sLineSegments << [sx + vec2_xlength*(distanceFromWall) + vec1_xlength*(wide - distanceFromWall - remainLong - pipeSpace2*3 + cornerRadius - pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall) + vec1_ylength*(wide - distanceFromWall - remainLong - pipeSpace2*3 + cornerRadius - pipeSpace2*4*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius) + vec1_xlength*(wide - distanceFromWall - remainLong - pipeSpace2*3 - pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall + cornerRadius) + vec1_ylength*(wide - distanceFromWall - remainLong - pipeSpace2*3 - pipeSpace2*4*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - remainLong - pipeSpace2*3 - pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - remainLong - pipeSpace2*3 - pipeSpace2*4*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_xlength*(wide - distanceFromWall - remainLong - pipeSpace2*4 - pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - pipeSpace2/2) + vec1_ylength*(wide - distanceFromWall - remainLong - pipeSpace2*4 - pipeSpace2*4*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius) + vec1_xlength*(wide - distanceFromWall - remainLong - pipeSpace2*4 - pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall + cornerRadius) + vec1_ylength*(wide - distanceFromWall - remainLong - pipeSpace2*4 - pipeSpace2*4*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall) + vec1_xlength*(wide - distanceFromWall - remainLong - pipeSpace2*4 - cornerRadius - pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall) + vec1_ylength*(wide - distanceFromWall - remainLong - pipeSpace2*4 - cornerRadius - pipeSpace2*4*i), 0]
				}
				sLineSegments << [sx + vec2_xlength*(distanceFromWall), sy + vec2_ylength*(distanceFromWall), 0]	

			elsif reciprocateType == 2
				#往的循环部分
				(0..(inCount/4).to_i).each { |i|
					if i == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2 + distanceFromWall/4) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(distanceFromWall + pipeSpace2 + distanceFromWall/4) + vec1_ylength*(distanceFromWall), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace2*4*i), 0]
					end
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(distanceFromWall + pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*(distanceFromWall + pipeSpace2*4*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + cornerRadius + pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + cornerRadius + pipeSpace2*4*i), 0]
					if i != (inCount/4).to_i 
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + pipeSpace2*3 - cornerRadius + pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + pipeSpace2*3 - cornerRadius + pipeSpace2*4*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(distanceFromWall + pipeSpace2*3 + pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall -cornerRadius) + vec1_ylength*(distanceFromWall + pipeSpace2*3 + pipeSpace2*4*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_xlength*(distanceFromWall + pipeSpace2*3 + pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall + pipeSpace2/2 + pipeSpace2/2) + vec1_ylength*(distanceFromWall + pipeSpace2*3 + pipeSpace2*4*i), 0]
					else
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*(wide - distanceFromWall), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + (pipeSpace2 + remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + (pipeSpace2 + remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall), 0]
					end
				}
				#复的循环
				(0..(inCount/4).to_i).each { |i|
					if i == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + (pipeSpace2 + remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall - (pipeSpace2 + remainLong/2) - pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall + (pipeSpace2 + remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall - (pipeSpace2 + remainLong/2) - pipeSpace2*4*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - (pipeSpace2 + remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall - (pipeSpace2 + remainLong/2) - pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - (pipeSpace2 + remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall - (pipeSpace2 + remainLong/2) - pipeSpace2*4*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - (pipeSpace2 + remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall - (pipeSpace2*2 + remainLong) - pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - (pipeSpace2 + remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall - (pipeSpace2*2 + remainLong) - pipeSpace2*4*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius) + vec1_xlength*(wide - distanceFromWall - pipeSpace2*2 - remainLong - pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall + cornerRadius) + vec1_ylength*(wide - distanceFromWall - pipeSpace2*2 - remainLong - pipeSpace2*4*i), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + (pipeSpace2 + remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall - remainLong - pipeSpace2 - pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall + (pipeSpace2 + remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall - remainLong - pipeSpace2 - pipeSpace2*4*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - (pipeSpace2 + remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall - remainLong - pipeSpace2 - pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - (pipeSpace2 + remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall - remainLong - pipeSpace2 - pipeSpace2*4*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace2/2 - (pipeSpace2 + remainLong/2)/2) + vec1_xlength*(wide - distanceFromWall - remainLong - pipeSpace2*2 - pipeSpace2*4*i), sy + vec2_ylength*(long - distanceFromWall - pipeSpace2/2 - (pipeSpace2 + remainLong/2)/2) + vec1_ylength*(wide - distanceFromWall - remainLong - pipeSpace2*2 - pipeSpace2*4*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius) + vec1_xlength*(wide - distanceFromWall - remainLong - pipeSpace2*2 - pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall + cornerRadius) + vec1_ylength*(wide - distanceFromWall - remainLong - pipeSpace2*2 - pipeSpace2*4*i), 0]
				
					end
					sLineSegments << [sx + vec2_xlength*(distanceFromWall) + vec1_xlength*(wide - distanceFromWall - pipeSpace2*2 - remainLong - cornerRadius - pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall) + vec1_ylength*(wide - distanceFromWall - pipeSpace2*2 - remainLong - cornerRadius - pipeSpace2*4*i), 0]
					if i != (inCount/4).to_i 
						sLineSegments << [sx + vec2_xlength*(distanceFromWall) + vec1_xlength*(wide - distanceFromWall - remainLong - pipeSpace2*5 + cornerRadius - pipeSpace2*4*i), sy + vec2_ylength*(distanceFromWall) + vec1_ylength*(wide - distanceFromWall - remainLong - pipeSpace2*5 + cornerRadius - pipeSpace2*4*i), 0]	
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall), sy + vec2_ylength*(distanceFromWall), 0]	
					end
				}
			
			end
			
		when 10
		
		end
		sLineSegments
	end 
	
	
	
	#画线
	def draw_line(points)
		model = Sketchup.active_model
		ent = model.entities
		model.start_operation 'add', true
		points.each_cons(2){|e|
			ent.add_line e[0], e[1]
		}
		model.commit_operation 
	
	end
	
end
	
# WaiqiangLine.new.run
