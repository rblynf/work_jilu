# require 'common_ly/chartComponents.rb'

include Math
class Pipe_line
  ##################### Pipe_line.new.array_type_line
  #直列型管道
  #####################
  def run(safe_distance = 150.mm,
          outer_area_spacing = 200.mm,
          inner_area_spacing = 250.mm,
          special_size = 5,
          cornerRadius = inner_area_spacing/2,
          limit_length = 100000.mm,
          origin = [200.mm, 500.mm, 0],
          vec1 = [1, 1, 0],
          vec2 = [-1, 1, 0],
          long = 4000.mm,
          wide = 3000.mm)
    sx = origin.x
    sy = origin.y

    vec1_length = Math.sqrt(vec1[0]*vec1[0] + vec1[1]*vec1[1])
    vec2_length = Math.sqrt(vec2[0]*vec2[0] + vec2[1]*vec2[1])
    #vec1方向上每1个单位长度对应x、y轴方向上的长度
    vec1_xlength = (vec1[0]/vec1_length)*1
    vec1_ylength = (vec1[1]/vec1_length)*1

    #vec2方向上每1个单位长度对应x、y轴方向上的长度
    vec2_xlength = (vec2[0]/vec2_length)*1
    vec2_ylength = (vec2[1]/vec2_length)*1

    #无外墙
    # if line_lists.length == 0
    # 离墙距离
    distanceFromWall = safe_distance
    pipeSpace = inner_area_spacing #间距取内间距
    inCount = ((long - distanceFromWall*2)/pipeSpace).to_i
    if inCount%2 == 0 #奇数，管道可以返回
      inCount = inCount - 1
    end
    #房间有剩余部分，扩大中间管线的间距以使房间填充满
    pipeSpace_2 = pipeSpace
    remainLong = 0
    if (long - distanceFromWall*2 - pipeSpace*inCount) > 0.mm
      # 剩余长度
      remainLong = long - distanceFromWall*2 - pipeSpace*inCount
    end
    #圆弧与直线管道的间距
    arcDisLine = pipeSpace/2

    sLineSegments_2 = []

    pipeSpace_2 = pipeSpace + remainLong/3
    sLineSegments_2 << run2(sx, sy, vec1_xlength, vec1_ylength, vec2_xlength, vec2_ylength, pipeSpace, pipeSpace_2, long, wide, arcDisLine, distanceFromWall, inCount, cornerRadius)

    pipeSpace = pipeSpace + remainLong/(inCount)
    pipeSpace_2 = pipeSpace
    sLineSegments_2 << run2(sx, sy, vec1_xlength, vec1_ylength, vec2_xlength, vec2_ylength, pipeSpace, pipeSpace_2, long, wide, arcDisLine, distanceFromWall, inCount, cornerRadius)
    # end #end 无外墙
    sLineSegments_2
  end

  #end  def


  def run2(sx, sy, vec1_xlength, vec1_ylength, vec2_xlength, vec2_ylength, pipeSpace, pipeSpace_2, long, wide, arcDisLine, distanceFromWall, inCount, cornerRadius)

    #先定义各类型端点数组，以便存放管理端点
    sLineSegments = [] #直线段端点数组
    # arcSegment = [] #圆弧线段端点数组

    # 1.管道入口部分
    inSPosition = [sx + vec2_xlength*distanceFromWall, sy + vec2_ylength*distanceFromWall, 0]
    inEPosition = [sx + vec2_xlength*distanceFromWall + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2), sy + vec2_ylength*distanceFromWall + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2), 0]
    sLineSegments << inSPosition
    sLineSegments << inEPosition

    #管道循环
    #计算第i条直线端点的坐标..
    (0..inCount).each { |i|
      if i < (inCount-1)/2 - 1
        if i%2 == 0
          if i != 0
            sLineSegments << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_xlength*distanceFromWall + vec2_xlength*pipeSpace*i, sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_ylength*distanceFromWall + vec2_ylength*pipeSpace*i, 0]
            sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*distanceFromWall + vec2_xlength*pipeSpace*i, sy + vec1_ylength*(wide - (distanceFromWall + pipeSpace/2)) + vec2_ylength*distanceFromWall + vec2_ylength*pipeSpace*i, 0]
            # arcSegment << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_xlength*distanceFromWall + vec2_xlength*pipeSpace*i, sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_ylength*distanceFromWall + vec2_ylength*pipeSpace*i, 0]
            # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*distanceFromWall + vec2_xlength*pipeSpace*i, sy + vec1_ylength*(wide - (distanceFromWall + pipeSpace/2)) + vec2_ylength*distanceFromWall + vec2_ylength*pipeSpace*i, 0]
          else
            sLineSegments.pop()
            sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*distanceFromWall + vec2_xlength*pipeSpace*i, sy + vec1_ylength*(wide - (distanceFromWall + pipeSpace/2)) + vec2_ylength*distanceFromWall + vec2_ylength*pipeSpace*i, 0]
            # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*distanceFromWall + vec2_xlength*pipeSpace*i, sy + vec1_ylength*(wide - (distanceFromWall + pipeSpace/2)) + vec2_ylength*distanceFromWall + vec2_ylength*pipeSpace*i, 0]
          end
        else
          sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*distanceFromWall + vec2_xlength*pipeSpace*i, sy + vec1_ylength*(wide - (distanceFromWall + pipeSpace/2)) + vec2_ylength*distanceFromWall + vec2_ylength*pipeSpace*i, 0]
          sLineSegments << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_xlength*distanceFromWall + vec2_xlength*pipeSpace*i, sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_ylength*distanceFromWall + vec2_ylength*pipeSpace*i, 0]
          # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*distanceFromWall + vec2_xlength*pipeSpace*i, sy + vec1_ylength*(wide - (distanceFromWall + pipeSpace/2)) + vec2_ylength*distanceFromWall + vec2_ylength*pipeSpace*i, 0]
          # arcSegment << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_xlength*distanceFromWall + vec2_xlength*pipeSpace*i, sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_ylength*distanceFromWall + vec2_ylength*pipeSpace*i, 0]
        end
      elsif i == (inCount-1)/2 - 1
        if i%2 == 0
          sLineSegments << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*i), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_ylength*(distanceFromWall + pipeSpace*i), 0]
          sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*i), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*i), 0]
          # arcSegment << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*i), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_ylength*(distanceFromWall + pipeSpace*i), 0]
          # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*i), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*i), 0]
        else
          sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*i), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace/2) + vec2_ylength*(distanceFromWall + pipeSpace*i), 0]
          sLineSegments << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*i), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*i), 0]
          # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*i), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace/2) + vec2_ylength*(distanceFromWall + pipeSpace*i), 0]
          # arcSegment << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*i), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*i), 0]
        end
      elsif i == (inCount-1)/2
        if i%2 == 0
          sLineSegments << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), 0]
          sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), 0]
          # arcSegment << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), 0]
          # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), 0]
        else
          sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), 0]
          sLineSegments << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), 0]
          # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), 0]
          # arcSegment << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-1) + pipeSpace_2), 0]
        end
      elsif i == (inCount-1)/2 + 1
        if i%2 == 0
          sLineSegments << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), 0]
          sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), 0]
          # arcSegment << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), 0]
          # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), 0]
        else
          sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), 0]
          sLineSegments << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), 0]
          # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), 0]
          # arcSegment << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-2) + pipeSpace_2*2), 0]
        end
      elsif i == (inCount-1)/2 + 2
        if i%2 == 0
          sLineSegments << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
          sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
          # arcSegment << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
          # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
        else
          sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
          sLineSegments << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
          # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
          # arcSegment << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
        end
      else
        if i%2 == 0
          sLineSegments << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
          sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(wide - (distanceFromWall + pipeSpace/2)) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
          # arcSegment << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
          # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(wide - (distanceFromWall + pipeSpace/2)) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
        else
          sLineSegments << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(wide - (distanceFromWall + pipeSpace/2)) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
          sLineSegments << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
          # arcSegment << [sx + vec1_xlength*(wide - distanceFromWall - pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(wide - (distanceFromWall + pipeSpace/2)) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
          # arcSegment << [sx + vec1_xlength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_xlength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), sy + vec1_ylength*(distanceFromWall + arcDisLine + pipeSpace/2) + vec2_ylength*(distanceFromWall + pipeSpace*(i-3) + pipeSpace_2*3), 0]
        end
      end
    }

    #3.管道收尾出口部分
    sLineSegments.pop()
    # arcSegment.pop()
    sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
    # arcSegment << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + cornerRadius), 0]

    # arcSegment << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*(distanceFromWall), 0]
    sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*(distanceFromWall), 0]

    # if cornerRadius > distanceFromWall
      sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace + distanceFromWall/4) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(distanceFromWall + pipeSpace + distanceFromWall/4) + vec1_ylength*(distanceFromWall), 0]
      # arcSegment << [sx + vec2_xlength*(distanceFromWall + pipeSpace + distanceFromWall/4) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(distanceFromWall + pipeSpace + distanceFromWall/4) + vec1_ylength*(distanceFromWall), 0]

      # arcSegment << [sx + vec2_xlength*(distanceFromWall + pipeSpace) + vec1_xlength*(distanceFromWall*3/4), sy + vec2_ylength*(distanceFromWall + pipeSpace) + vec1_ylength*(distanceFromWall*3/4), 0]
      sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace) + vec1_xlength*(distanceFromWall*3/4), sy + vec2_ylength*(distanceFromWall + pipeSpace) + vec1_ylength*(distanceFromWall*3/4), 0]

      sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace), sy + vec2_ylength*(distanceFromWall + pipeSpace), 0]
    # else
    #   sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace + cornerRadius) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(distanceFromWall + pipeSpace + cornerRadius) + vec1_ylength*(distanceFromWall), 0]
      # arcSegment << [sx + vec2_xlength*(distanceFromWall + pipeSpace + cornerRadius) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(distanceFromWall + pipeSpace + cornerRadius) + vec1_ylength*(distanceFromWall), 0]

      # arcSegment << [sx + vec2_xlength*(distanceFromWall + pipeSpace) + vec1_xlength*(distanceFromWall - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace) + vec1_ylength*(distanceFromWall - cornerRadius), 0]
      # sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace) + vec1_xlength*(distanceFromWall - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace) + vec1_ylength*(distanceFromWall - cornerRadius), 0]

      # sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace), sy + vec2_ylength*(distanceFromWall + pipeSpace), 0]
    # end
    sLineSegments
  end


  #画线
  def draw_line(points)
    model = Sketchup.active_model
    ent = model.entities
    model.start_operation 'add', true
    points.each_slice(2) { |e|
      ent.add_line e[0], e[1]
    }
    model.commit_operation

  end

end

# Pipe_line.new.run
