=begin
往复型管道
入参：sx管道入口房间角x坐标  sy管道入口房间角y坐标  long房间长    wide房间宽  
	   pipeSpace管道间距   distance离墙距离最小值(小于pipeSpace/2)
=end

include Math

class Reciprocate

  def run(safe_distance = 150.mm,
          outer_area_spacing = 200.mm,
          inner_area_spacing = 200.mm,
          special_size = 5,
          cornerRadius = 120.mm,
          limit_length = 100000.mm,
          origin = [200.mm, 500.mm, 0],
          vec1 = [1, 1, 0],
          vec2 = [-1, 1, 0],
          long = 4350.mm,
          wide = 3550.mm)
    sx = origin.x
    sy = origin.y

    vec1_length = Math.sqrt(vec1[0]*vec1[0] + vec1[1]*vec1[1])
    vec2_length = Math.sqrt(vec2[0]*vec2[0] + vec2[1]*vec2[1])
    #vec1方向上每1个单位长度对应x、y轴方向上的长度
    vec1_xlength = (vec1[0]/vec1_length)*1
    vec1_ylength = (vec1[1]/vec1_length)*1

    #vec2方向上每1个单位长度对应x、y轴方向上的长度
    vec2_xlength = (vec2[0]/vec2_length)*1
    vec2_ylength = (vec2[1]/vec2_length)*1

    pipeSpace = inner_area_spacing
    distanceFromWall = safe_distance

    #管道间距数
    inCount = ((long - distanceFromWall*2)/pipeSpace).to_i
    remainLong = long - distanceFromWall*2 - pipeSpace*inCount
    reciprocateType = 0 #标志
    if inCount%4 == 1
      reciprocateType = 1 #出入口方向与返回口方向不一致
    elsif inCount%4 == 3
      reciprocateType = 2
    elsif inCount%4 == 2 #余2
      reciprocateType = 1
      inCount = inCount - 1
      remainLong += pipeSpace
    else #整除时
      reciprocateType = 2
      inCount = inCount - 1
      remainLong += pipeSpace
    end

    #定义数组
    sLineSegments_2 = []

    pipeSpace_2 = pipeSpace + remainLong/2
    sLineSegments_2 << common_operate(sx, sy, vec1_xlength, vec1_ylength, vec2_xlength, vec2_ylength, pipeSpace, pipeSpace_2, long, wide, distanceFromWall, inCount, cornerRadius, reciprocateType, remainLong)

    #均分
    pipeSpace = pipeSpace + remainLong/inCount
    pipeSpace_2 = pipeSpace
    remainLong = 0
    sLineSegments_2 << common_operate(sx, sy, vec1_xlength, vec1_ylength, vec2_xlength, vec2_ylength, pipeSpace, pipeSpace_2, long, wide, distanceFromWall, inCount, cornerRadius, reciprocateType, remainLong)

    #画线
    # draw_line(sLineSegments_2[0])

    sLineSegments_2
  end

  #共同部分
  def common_operate(sx, sy, vec1_xlength, vec1_ylength, vec2_xlength, vec2_ylength, pipeSpace, pipeSpace_2, long, wide, distanceFromWall, inCount, cornerRadius, reciprocateType, remainLong)

    #先定义各类型端点数组，以便存放管理端点
    sLineSegments = [] #直线段端点数组

    #入口
    inSPosition = [sx + vec2_xlength*distanceFromWall, sy + vec2_ylength*distanceFromWall, 0]
    inEPosition = [sx + vec2_xlength*distanceFromWall + vec1_xlength*(distanceFromWall + pipeSpace + pipeSpace/2), sy + vec2_ylength*distanceFromWall + vec1_ylength*(distanceFromWall + pipeSpace + pipeSpace/2), 0]

    sLineSegments << inSPosition
    sLineSegments << inEPosition

    if reciprocateType == 1
      #往的循环部分
      (0...inCount/4).each { |i|
        sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*4*i) + vec1_xlength*(distanceFromWall + pipeSpace + pipeSpace/2), sy + vec2_ylength*(distanceFromWall + pipeSpace*4*i) + vec1_ylength*(distanceFromWall + pipeSpace + pipeSpace/2), 0]
        sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*4*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace*4*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]

        sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius + pipeSpace*4*i) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + cornerRadius + pipeSpace*4*i) + vec1_ylength*(wide - distanceFromWall), 0]
        sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*3 - cornerRadius + pipeSpace*4*i) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + pipeSpace*3 - cornerRadius + pipeSpace*4*i) + vec1_ylength*(wide - distanceFromWall), 0]

        sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*3 + pipeSpace*4*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace*3 + pipeSpace*4*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
        if i != (inCount/4).to_i - 1
          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*3 + pipeSpace*4*i) + vec1_xlength*(distanceFromWall + pipeSpace + pipeSpace/2), sy + vec2_ylength*(distanceFromWall + pipeSpace*3 + pipeSpace*4*i) + vec1_ylength*(distanceFromWall + pipeSpace + pipeSpace/2), 0]
        else
          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*3 + pipeSpace*4*i) + vec1_xlength*(distanceFromWall + pipeSpace + pipeSpace_2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace*3 + pipeSpace*4*i) + vec1_ylength*(distanceFromWall + pipeSpace + pipeSpace_2/2), 0]

        end
      }
      #往的后一段
      sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*4*(inCount/4) + remainLong/2) + vec1_xlength*(distanceFromWall + pipeSpace + pipeSpace_2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace*4*(inCount/4) + remainLong/2) + vec1_ylength*(distanceFromWall + pipeSpace + pipeSpace_2/2), 0]
      sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*4*(inCount/4) + remainLong/2) + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace*4*(inCount/4) + remainLong/2) + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2), 0]

      #一小段竖直线段
      sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*4*(inCount/4) + pipeSpace + remainLong) + vec1_xlength*(wide - distanceFromWall - pipeSpace_2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace*4*(inCount/4) + pipeSpace + remainLong) + vec1_ylength*(wide - distanceFromWall - pipeSpace_2/2), 0]
      sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*4*(inCount/4) + pipeSpace + remainLong) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace*4*(inCount/4) + pipeSpace + remainLong) + vec1_ylength*(distanceFromWall + cornerRadius), 0]

      #复的循环部分
      (0...inCount/4).each { |i|
        if i == 0
          sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - cornerRadius) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - cornerRadius) + vec1_ylength*(distanceFromWall), 0]
          sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace_2*2 - (pipeSpace - cornerRadius)) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(long - distanceFromWall - pipeSpace_2*2 - (pipeSpace - cornerRadius)) + vec1_ylength*(distanceFromWall), 0]

          sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace_2*2 - pipeSpace) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - distanceFromWall - pipeSpace_2*2 - pipeSpace) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
          sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace_2*2 - pipeSpace) + vec1_xlength*(wide - distanceFromWall - pipeSpace - pipeSpace/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace_2*2 - pipeSpace) + vec1_ylength*(wide - distanceFromWall - pipeSpace - pipeSpace/2), 0]

          sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace_2*2 - pipeSpace - pipeSpace) + vec1_xlength*(wide - distanceFromWall - pipeSpace - pipeSpace/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace_2*2 - pipeSpace - pipeSpace) + vec1_ylength*(wide - distanceFromWall - pipeSpace - pipeSpace/2), 0]
          sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace_2*2 - pipeSpace - pipeSpace) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - distanceFromWall - pipeSpace_2*2 - pipeSpace - pipeSpace) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
        else
          sLineSegments << [sx + vec2_xlength*(long - pipeSpace*4*(i-1) - pipeSpace*2 - pipeSpace_2*2 - distanceFromWall - cornerRadius) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(long - pipeSpace*4*(i-1) - pipeSpace*2 - pipeSpace_2*2- distanceFromWall - cornerRadius) + vec1_ylength*(distanceFromWall), 0]
          sLineSegments << [sx + vec2_xlength*(long - pipeSpace*4*(i-1) - pipeSpace*2 - pipeSpace_2*2 - distanceFromWall - (pipeSpace*3 - cornerRadius)) + vec1_xlength*(distanceFromWall), sy + vec2_ylength*(long - pipeSpace*4*(i-1) - pipeSpace*2 - pipeSpace_2*2 - distanceFromWall - (pipeSpace*3 - cornerRadius)) + vec1_ylength*(distanceFromWall), 0]

          sLineSegments << [sx + vec2_xlength*(long - pipeSpace*4*(i-1) - pipeSpace*2 - pipeSpace_2*2 - distanceFromWall - pipeSpace*3) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - pipeSpace*4*(i-1) - pipeSpace*2 - pipeSpace_2*2 - distanceFromWall - pipeSpace*3) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
          sLineSegments << [sx + vec2_xlength*(long - pipeSpace*4*(i-1) - pipeSpace*2 - pipeSpace_2*2 - distanceFromWall - pipeSpace*3) + vec1_xlength*(wide - distanceFromWall - pipeSpace - pipeSpace/2), sy + vec2_ylength*(long - pipeSpace*4*(i-1) - pipeSpace*2 - pipeSpace_2*2 - distanceFromWall - pipeSpace*3) + vec1_ylength*(wide - distanceFromWall - pipeSpace - pipeSpace/2), 0]

          sLineSegments << [sx + vec2_xlength*(long - pipeSpace*4*(i-1) - pipeSpace*2 - pipeSpace_2*2 - distanceFromWall - pipeSpace*4) + vec1_xlength*(wide - distanceFromWall - pipeSpace - pipeSpace/2), sy + vec2_ylength*(long - pipeSpace*4*(i-1) - pipeSpace*2 - pipeSpace_2*2 - distanceFromWall - pipeSpace*4) + vec1_ylength*(wide - distanceFromWall - pipeSpace - pipeSpace/2), 0]
          if i != (inCount/4).to_i - 1
            sLineSegments << [sx + vec2_xlength*(long - pipeSpace*4*(i-1) - pipeSpace*2 - pipeSpace_2*2 - distanceFromWall - pipeSpace*4) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(long - pipeSpace*4*(i-1) - pipeSpace*2 - pipeSpace_2*2 - distanceFromWall - pipeSpace*4) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
          else
            # 出口
            sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace), sy + vec2_ylength*(distanceFromWall + pipeSpace), 0]
          end
        end
      }
    elsif reciprocateType == 2
      #往的循环部分
      (0..inCount/4).each { |i|
        sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*4*i) + vec1_xlength*(distanceFromWall + pipeSpace + pipeSpace/2), sy + vec2_ylength*(distanceFromWall + pipeSpace*4*i) + vec1_ylength*(distanceFromWall + pipeSpace + pipeSpace/2), 0]
        sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*4*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace*4*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]

        sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius + pipeSpace*4*i) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + cornerRadius + pipeSpace*4*i) + vec1_ylength*(wide - distanceFromWall), 0]
        if i != (inCount/4).to_i
          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*3 - cornerRadius + pipeSpace*4*i) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + pipeSpace*3 - cornerRadius + pipeSpace*4*i) + vec1_ylength*(wide - distanceFromWall), 0]

          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*3 + pipeSpace*4*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace*3 + pipeSpace*4*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*3 + pipeSpace*4*i) + vec1_xlength*(distanceFromWall + pipeSpace + pipeSpace/2), sy + vec2_ylength*(distanceFromWall + pipeSpace*3 + pipeSpace*4*i) + vec1_ylength*(distanceFromWall + pipeSpace + pipeSpace/2), 0]
        else
          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*3 - cornerRadius + remainLong + pipeSpace*4*i) + vec1_xlength*(wide - distanceFromWall), sy + vec2_ylength*(distanceFromWall + pipeSpace*3 - cornerRadius + remainLong + pipeSpace*4*i) + vec1_ylength*(wide - distanceFromWall), 0]
          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*3 + remainLong + pipeSpace*4*i) + vec1_xlength*(wide - distanceFromWall - cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace*3 + remainLong + pipeSpace*4*i) + vec1_ylength*(wide - distanceFromWall - cornerRadius), 0]
          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*3 + remainLong + pipeSpace*4*i) + vec1_xlength*(distanceFromWall + pipeSpace + pipeSpace/2), sy + vec2_ylength*(distanceFromWall + pipeSpace*3 + remainLong + pipeSpace*4*i) + vec1_ylength*(distanceFromWall + pipeSpace + pipeSpace/2), 0]
        end
      }

      #往的后一段
      sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + pipeSpace + pipeSpace/2), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + pipeSpace + pipeSpace/2), 0]
      sLineSegments << [sx + vec2_xlength*(long - distanceFromWall) + vec1_xlength*(distanceFromWall + pipeSpace_2/2), sy + vec2_ylength*(long - distanceFromWall) + vec1_ylength*(distanceFromWall + pipeSpace_2/2), 0]

      #复的循环部分
      (0..inCount/4).each { |i|
        if i != 0
          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*(inCount - 1 - 4*i)) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace*(inCount - 1 - 4*i)) + vec1_ylength*(distanceFromWall + cornerRadius), 0]
          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*(inCount - 1 - 4*i)) + vec1_xlength*(wide - distanceFromWall - pipeSpace - pipeSpace/2), sy + vec2_ylength*(distanceFromWall + pipeSpace*(inCount-1 - 4*i)) + vec1_ylength*(wide - distanceFromWall - pipeSpace - pipeSpace/2), 0]

          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*(inCount - 2 - 4*i)) + vec1_xlength*(wide - distanceFromWall - pipeSpace - pipeSpace/2), sy + vec2_ylength*(distanceFromWall + pipeSpace*(inCount - 2 - 4*i)) + vec1_ylength*(wide - distanceFromWall - pipeSpace - pipeSpace/2), 0]
        else
          sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace_2) + vec1_xlength*(distanceFromWall + pipeSpace_2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace_2) + vec1_ylength*(distanceFromWall + pipeSpace_2/2), 0]
          sLineSegments << [sx + vec2_xlength*(long - distanceFromWall - pipeSpace_2) + vec1_xlength*(wide - distanceFromWall - pipeSpace - pipeSpace_2/2), sy + vec2_ylength*(long - distanceFromWall - pipeSpace_2) + vec1_ylength*(wide - distanceFromWall - pipeSpace - pipeSpace_2/2), 0]

          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*(inCount - 2 - 4*i)) + vec1_xlength*(wide - distanceFromWall - pipeSpace - pipeSpace_2/2), sy + vec2_ylength*(distanceFromWall + pipeSpace*(inCount - 2 - 4*i)) + vec1_ylength*(wide - distanceFromWall - pipeSpace - pipeSpace_2/2), 0]
        end
        if i != (inCount/4).to_i
          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace*(inCount - 2 - 4*i)) + vec1_xlength*(distanceFromWall + cornerRadius), sy + vec2_ylength*(distanceFromWall + pipeSpace*(inCount - 2 - 4*i)) + vec1_ylength*(distanceFromWall + cornerRadius), 0]

          sLineSegments << [sx + vec2_xlength*(distanceFromWall - cornerRadius + pipeSpace*(inCount - 2 - 4*i)) + vec1_xlength*distanceFromWall, sy + vec2_ylength*(distanceFromWall - cornerRadius + pipeSpace*(inCount - 2 - 4*i)) + vec1_ylength*distanceFromWall, 0]
          sLineSegments << [sx + vec2_xlength*(distanceFromWall + cornerRadius + pipeSpace*(inCount - 5 - 4*i)) + vec1_xlength*distanceFromWall, sy + vec2_ylength*(distanceFromWall + cornerRadius + pipeSpace*(inCount - 5 - 4*i)) + vec1_ylength*distanceFromWall, 0]
        else
          # 出口
          sLineSegments << [sx + vec2_xlength*(distanceFromWall + pipeSpace), sy + vec2_ylength*(distanceFromWall + pipeSpace), 0]
        end

      }
    end #end if
    sLineSegments

  end


  #画线
  def draw_line(points)
    model = Sketchup.active_model
    ent = model.entities
    model.start_operation 'add', true
    points.each_slice(2) { |e|
      ent.add_line e[0], e[1]
    }
    model.commit_operation
  end


end

# Reciprocate.new.run

