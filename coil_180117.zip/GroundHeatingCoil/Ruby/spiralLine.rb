include Math
##################### Pipe_line.new.array_type_line
#螺旋型管道
# 
#####################
class SpiralLine
	def run(safe_distance = 150.mm, outer_area_spacing = 200.mm, inner_area_spacing = 200.mm, special_size = 5,  cornerRadius = 120.mm, limit_length = 100000.mm, origin = [200.mm,500.mm,0], vec1 = [1,1,0], vec2 = [-1,1,0], long = 4020.mm, wide = 4030.mm)
		sx = origin.x
		sy = origin.y

		# if vec1_x*vec2_x + vec1_y*vec2_y == 0
		vec1_length = Math.sqrt(vec1[0]*vec1[0] + vec1[1]*vec1[1])
		vec2_length = Math.sqrt(vec2[0]*vec2[0] + vec2[1]*vec2[1])
		#vec1方向上每1个单位长度对应x、y轴方向上的长度
		vec1_xlength = (vec1[0]/vec1_length)*1
		vec1_ylength = (vec1[1]/vec1_length)*1

		#vec2方向上每1个单位长度对应x、y轴方向上的长度
		vec2_xlength = (vec2[0]/vec2_length)*1
		vec2_ylength = (vec2[1]/vec2_length)*1

		pipeSpace = inner_area_spacing
		distanceFromWall = safe_distance
		distanceFromWall_x = distanceFromWall
		distanceFromWall_y = distanceFromWall

		#图形样式由长和宽的大小决定,且最好相差>2*pipeSpace。
		if long >= wide
			#wide方向上的一边的管道间隔数
			inCount = ((wide - distanceFromWall*2)/(pipeSpace*2)).to_i
			remianWide = (wide - distanceFromWall*2 - pipeSpace*2*inCount)
			if inCount%2 == 0 || (remianWide >= pipeSpace*3/2 && inCount%2 != 0)
				if inCount%2 == 0
					inCount = inCount - 1
					remianWide += pipeSpace*2
				end
				pipeSpace_2 = remianWide/3
				#先定义各类型端点数组，以便存放管理端点
				sLineSegments = [] #直线段端点数组
				#第一条竖直线段端点(入口)
				sLineSegments << [sx + vec2_xlength*distanceFromWall_x, sy + vec2_ylength*distanceFromWall_y, 0]
				sLineSegments << [sx + vec2_xlength*distanceFromWall_x + vec1_xlength*(wide - distanceFromWall_y - cornerRadius), sy + vec2_ylength*distanceFromWall_x + vec1_ylength*(wide - distanceFromWall_y - cornerRadius), 0]
				@num = (inCount+1)/2
				#从1/4(右上)圆弧开始循环
				(0...@num).each { |i|
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + cornerRadius + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + cornerRadius + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2*i), 0]
					#左下圆弧端点
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), 0]

					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + cornerRadius + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + cornerRadius + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*i), 0]
					#右下圆弧
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + cornerRadius+ pipeSpace*2*i), 0]
					if i != @num - 1
					  sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2 - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2 - pipeSpace*2*i), 0]
					else
					  sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - cornerRadius - pipeSpace - pipeSpace_2 - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - cornerRadius - pipeSpace - pipeSpace_2 - pipeSpace*2*i), 0]
					end
				}

				#中间转回部分
				# 1/4右上圆弧端点
				sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*(inCount+1) + cornerRadius) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount - pipeSpace_2), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*(inCount+1) + cornerRadius) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount - pipeSpace_2), 0]
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*(inCount+1) - pipeSpace_2/2) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount - pipeSpace_2), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*(inCount+1) - pipeSpace_2/2) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount - pipeSpace_2), 0]

				#左-右
				sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*(inCount+1) - pipeSpace_2/2) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount- pipeSpace_2*2), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*(inCount+1) - pipeSpace_2/2) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount - pipeSpace_2*2), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace + pipeSpace_2/2) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount - pipeSpace_2*2), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace + pipeSpace_2/2) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount - pipeSpace_2*2), 0]

				##从下横线开始循环返回
				(0...@num).each { |i|
					if i == 0
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace + pipeSpace_2/2) + vec1_xlength*(distanceFromWall_y + pipeSpace*inCount), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace + pipeSpace_2/2) + vec1_ylength*(distanceFromWall_y + pipeSpace*inCount - pipeSpace*2*i), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*(inCount+2) + cornerRadius - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*inCount - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*(inCount+2) + cornerRadius - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*inCount - pipeSpace*2*i), 0]
					end
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*inCount - cornerRadius + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*inCount - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*inCount - cornerRadius + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*inCount - pipeSpace*2*i), 0]
					##	左下 - 上
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*inCount + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*inCount + cornerRadius - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*inCount + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*inCount + cornerRadius - pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*inCount + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount - cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*inCount + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount - cornerRadius + pipeSpace*2*i), 0]
					#上左 - 右
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*inCount - cornerRadius + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*inCount - cornerRadius + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount + pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*inCount + cornerRadius - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*inCount + cornerRadius - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount + pipeSpace*2*i), 0]

					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*inCount - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount - cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*inCount - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount - cornerRadius + pipeSpace*2*i), 0]
					if i != @num - 1
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*inCount - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*(inCount - 2) + cornerRadius - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*inCount - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*(inCount - 2) + cornerRadius - pipeSpace*2*i), 0]
					else
						#出口
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace), sy + vec2_ylength*(distanceFromWall_x + pipeSpace), 0]
					end
				}
			elsif (inCount%2 != 0 && remianWide < pipeSpace*3/2) #|| (inCount%2 == 0 && remianWide > pipeSpace*3/2)
				pipeSpace_2 = (remianWide+pipeSpace)/2 
				sLineSegments = [] #直线段端点数组
				if (long - wide) < pipeSpace
					remianLong = (long - distanceFromWall*2 - pipeSpace*2*inCount)
					inCount -= 1
					pipeSpace_2 = (remianLong + pipeSpace*3)/2
				end
				#第一条竖直线段端点(入口)
				sLineSegments << [sx + vec2_xlength*distanceFromWall_x, sy + vec2_ylength*distanceFromWall_y, 0]
				sLineSegments << [sx + vec2_xlength*distanceFromWall_x + vec1_xlength*(wide - distanceFromWall_y - cornerRadius), sy + vec2_ylength*distanceFromWall_x + vec1_ylength*(wide - distanceFromWall_y - cornerRadius), 0]

				@num = (inCount+1)/2
				#从1/4(右上)圆弧开始循环
				(0...@num).each { |i|
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + cornerRadius + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + cornerRadius + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2*i), 0]
					#左下圆弧端点
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*i), 0]
					#右下圆弧
					if i != @num - 1
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + cornerRadius + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + cornerRadius + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + cornerRadius+ pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2 - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2 - pipeSpace*2*i), 0]
					else
						if (long - wide) > pipeSpace
							sLineSegments << [sx + vec2_xlength*(long/2 + pipeSpace/2 + pipeSpace/2) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*i), sy + vec2_ylength*(long/2 + pipeSpace/2 + pipeSpace/2) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*i), 0]
							sLineSegments << [sx + vec2_xlength*(long/2 + pipeSpace/2 + pipeSpace/2 - cornerRadius) + vec1_xlength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(long/2 + pipeSpace/2 + pipeSpace/2 - cornerRadius) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*i + cornerRadius), 0]
							sLineSegments << [sx + vec2_xlength*(long/2 + pipeSpace/2 + pipeSpace/2 - cornerRadius) + vec1_xlength*(wide - distanceFromWall_y - cornerRadius - pipeSpace - pipeSpace*2*i), sy + vec2_ylength*(long/2 + pipeSpace/2 + pipeSpace/2 - cornerRadius) + vec1_ylength*(wide - distanceFromWall_y - cornerRadius - pipeSpace - pipeSpace*2*i), 0]
							sLineSegments << [sx + vec2_xlength*(long/2 + pipeSpace/2 + pipeSpace/2 - cornerRadius - cornerRadius) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*i), sy + vec2_ylength*(long/2 + pipeSpace/2 + pipeSpace/2 - cornerRadius - cornerRadius) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*i), 0]
						
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + cornerRadius + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + cornerRadius + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*i), 0]
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*i), 0]
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*(i-1) + pipeSpace + cornerRadius), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*(i-1) + pipeSpace + cornerRadius), 0]
						else
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*@num  + cornerRadius) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*(@num - 1)), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*@num + cornerRadius) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*(@num - 1)), 0]
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*@num) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*(@num - 1) + cornerRadius), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*@num) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*(@num - 1) + cornerRadius), 0]
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*@num) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*@num - cornerRadius), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*@num) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*@num - cornerRadius), 0]
							
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*@num + cornerRadius) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*@num), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*@num + cornerRadius) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*@num), 0]
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2 - cornerRadius) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*@num), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2 - cornerRadius) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*@num), 0]
              
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*@num - cornerRadius), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*@num - cornerRadius), 0]
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*(@num-1) + pipeSpace + cornerRadius), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*(@num-1) + pipeSpace + cornerRadius), 0]
		
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2 + cornerRadius) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*(@num-1) + pipeSpace), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2 + cornerRadius) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*(@num-1) + pipeSpace), 0]
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2*2 - cornerRadius) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*(@num-1) + pipeSpace), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2*2 - cornerRadius) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*(@num-1) + pipeSpace), 0]

							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2*2) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*(@num-1) + pipeSpace + cornerRadius), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2*2) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*(@num-1) + pipeSpace + cornerRadius), 0]
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2*2) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*@num + pipeSpace - cornerRadius), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2*2) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*@num + pipeSpace - cornerRadius), 0]

							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2*2 - cornerRadius) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*@num + pipeSpace), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*@num + pipeSpace_2*2 - cornerRadius) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*@num + pipeSpace), 0]
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*(@num-1) + pipeSpace + cornerRadius) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*@num + pipeSpace), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*(@num-1) + pipeSpace + cornerRadius) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*@num + pipeSpace), 0]

							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*(@num-1) + pipeSpace) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*@num + pipeSpace - cornerRadius), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*(@num-1) + pipeSpace) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*@num + pipeSpace - cornerRadius), 0]
							sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2*(@num-1) + pipeSpace) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*(@num-2) + pipeSpace + cornerRadius), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2*(@num-1) + pipeSpace) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*(@num-2) + pipeSpace + cornerRadius), 0]
						end
					end
				}
				#循环出去
				(0...(@num-1)).each{ |i|
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + cornerRadius + pipeSpace*2*((@num-2-i)+1)) + vec1_xlength*(distanceFromWall_y + pipeSpace + pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + cornerRadius + pipeSpace*2*((@num-2-i)+1)) + vec1_ylength*(distanceFromWall_y + pipeSpace + pipeSpace*2*(@num-2-i)), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)) + vec1_xlength*(distanceFromWall_y + pipeSpace + pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)) + vec1_ylength*(distanceFromWall_y + pipeSpace + pipeSpace*2*(@num-2-i)), 0]

					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace - pipeSpace*2*(@num-2-i)) + vec1_xlength*(distanceFromWall_y + pipeSpace + cornerRadius + pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace - pipeSpace*2*(@num-2-i)) + vec1_ylength*(distanceFromWall_y + pipeSpace + cornerRadius + pipeSpace*2*(@num-2-i)), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace - pipeSpace*2*(@num-2-i)) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace - pipeSpace*2*(@num-2-i)) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)), 0]

					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*(@num-2-i)), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + cornerRadius + pipeSpace*2*(@num-2-i)) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + cornerRadius + pipeSpace*2*(@num-2-i)) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*(@num-2-i)), 0]
					
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + pipeSpace*2*(@num-2-i)) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + pipeSpace*2*(@num-2-i)) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)), 0]
					if i == @num-2
						# 出口
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace), sy + vec2_ylength*(distanceFromWall_x + pipeSpace), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + pipeSpace*2*(@num-2-i)) + vec1_xlength*(distanceFromWall_y + pipeSpace + cornerRadius + pipeSpace*2*((@num-2-i)-1)), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + pipeSpace*2*(@num-2-i)) + vec1_ylength*(distanceFromWall_y + pipeSpace + cornerRadius + pipeSpace*2*((@num-2-i)-1)), 0]
					end
				}
			end
		else # long < wide
			#wide方向上的一边的管道间隔数
			inCount = ((long - distanceFromWall*2)/(pipeSpace*2)).to_i
			remianLong = (long - distanceFromWall*2 - pipeSpace*2*inCount)
			if inCount%2 == 0 || (remianLong >= pipeSpace*3/2 && inCount%2 != 0)
				if inCount%2 == 0
					inCount = inCount - 1
					remianLong += pipeSpace*2
				end
				pipeSpace_2 = remianLong/3
				#先定义各类型端点数组，以便存放管理端点
				sLineSegments = [] #直线段端点数组

				#第一条竖直线段端点(入口)
				sLineSegments << [sx + vec2_xlength*distanceFromWall_x, sy + vec2_ylength*distanceFromWall_y, 0]
				sLineSegments << [sx + vec2_xlength*distanceFromWall_x + vec1_xlength*(wide - distanceFromWall_y - cornerRadius), sy + vec2_ylength*distanceFromWall_x + vec1_ylength*(wide - distanceFromWall_y - cornerRadius), 0]
				@num = (inCount+1)/2
				#从1/4(右上)圆弧开始循环
				(0...@num).each { |i|
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + cornerRadius + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + cornerRadius + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2*i), 0]
					#左下圆弧端点
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + cornerRadius + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + cornerRadius + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*i), 0]
					#右下圆弧
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + cornerRadius+ pipeSpace*2*i), 0]
					if i != @num - 1
					  sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2 - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2 - pipeSpace*2*i), 0]
					else
					  sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2 - pipeSpace_2/2 - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2 - pipeSpace_2/2 - pipeSpace*2*i), 0]
					end
				}
				#中间转回部分
				sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace_2) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount - pipeSpace - pipeSpace_2/2), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace_2) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount - pipeSpace - pipeSpace_2/2), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace_2) + vec1_xlength*(distanceFromWall_y + pipeSpace*inCount + pipeSpace_2/2), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace_2) + vec1_ylength*(distanceFromWall_y + pipeSpace*inCount + pipeSpace_2/2), 0]
			
				sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace_2*2) + vec1_xlength*(distanceFromWall_y + pipeSpace*inCount + pipeSpace_2/2), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace_2*2) + vec1_ylength*(distanceFromWall_y + pipeSpace*inCount + pipeSpace_2/2), 0]
				sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace_2*2) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount - cornerRadius), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace_2*2) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount - cornerRadius), 0]
				
				##从上横线开始循环返回
				(0...@num).each { |i|
					if i == 0 
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace_2*2 - cornerRadius + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace_2*2 - cornerRadius + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount + pipeSpace*2*i), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace_2*3 - pipeSpace - cornerRadius + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*(inCount+1) + pipeSpace_2*3 - pipeSpace - cornerRadius + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount + pipeSpace*2*i), 0]
					end
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*inCount + cornerRadius - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*inCount + cornerRadius - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount + pipeSpace*2*i), 0]

					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*inCount - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*inCount - cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*inCount - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*inCount - cornerRadius + pipeSpace*2*i), 0]
					if i != @num-1
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*inCount - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*(inCount-2) + cornerRadius - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*inCount - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*(inCount-2) + cornerRadius - pipeSpace*2*i), 0]
						
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*inCount + cornerRadius - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*(inCount-2) - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*inCount + cornerRadius - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*(inCount-2) - pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*(inCount-2) - cornerRadius + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*(inCount-2) - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*(inCount-2) - cornerRadius + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*(inCount-2) - pipeSpace*2*i), 0]

						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*(inCount-2) + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*(inCount-2) + cornerRadius - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*(inCount-2) + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*(inCount-2) + cornerRadius - pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*(inCount-2) + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*(inCount-2) - cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*(inCount-2) + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*(inCount-2) - cornerRadius + pipeSpace*2*i), 0]

					else
						# 出口
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace), sy + vec2_ylength*(distanceFromWall_x + pipeSpace), 0]
					end
				}
			elsif (inCount%2 != 0 && remianLong < pipeSpace*3/2) #|| (inCount%2 == 0 && remianLong > pipeSpace*3/2)
				pipeSpace_2 = (remianLong + pipeSpace*3)/2 
				sLineSegments = [] #直线段端点数组
				
				#第一条竖直线段端点(入口)
				inSPosition = [sx + vec2_xlength*distanceFromWall_x, sy + vec2_ylength*distanceFromWall_y, 0]
				inEPosition = [sx + vec2_xlength*distanceFromWall_x + vec1_xlength*(wide - distanceFromWall_y - cornerRadius), sy + vec2_ylength*distanceFromWall_x + vec1_ylength*(wide - distanceFromWall_y - cornerRadius), 0]
				sLineSegments << inSPosition
				sLineSegments << inEPosition
				if (long - wide) < pipeSpace
					inCount -= 1
				end
				@num = (inCount+1)/2
				#从1/4(右上)圆弧开始循环
				(0...@num).each { |i|
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + cornerRadius + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + cornerRadius + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2*i), 0]
					#左下圆弧端点
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - cornerRadius - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*i), 0]
					#右下圆弧
					if i != @num - 1
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + cornerRadius + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + cornerRadius + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + cornerRadius+ pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2 - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2 - pipeSpace*2*i), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + cornerRadius + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + cornerRadius + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + cornerRadius + pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2 - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - cornerRadius - pipeSpace*2 - pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + cornerRadius + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2 - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + cornerRadius + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2 - pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace_2 - cornerRadius + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2 - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace_2 - cornerRadius + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2 - pipeSpace*2*i), 0]
						
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace_2 + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace*2 - cornerRadius - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace_2 + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace*2 - cornerRadius - pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace_2 + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace + cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace_2 + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace + cornerRadius + pipeSpace*2*i), 0]

						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace*2 + pipeSpace_2 + cornerRadius + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace + pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace*2 + pipeSpace_2 + cornerRadius + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace + pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace - cornerRadius - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace - cornerRadius - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace + pipeSpace*2*i), 0]

						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace - pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace + cornerRadius + pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace - pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace + cornerRadius + pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*i), 0]

						sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace - cornerRadius - pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*i), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace - cornerRadius - pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + cornerRadius + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + cornerRadius + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + pipeSpace*2*i) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*i), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + pipeSpace*2*i) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*i), 0]
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + pipeSpace*2*i) + vec1_xlength*(distanceFromWall_y + pipeSpace*2*(i-1) + pipeSpace + cornerRadius), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + pipeSpace*2*i) + vec1_ylength*(distanceFromWall_y + pipeSpace*2*(i-1) + pipeSpace + cornerRadius), 0]
					end
				}
				#循环出去
				(0...(@num-1)).each{ |i|
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + cornerRadius + pipeSpace*2*((@num-2-i)+1)) + vec1_xlength*(distanceFromWall_y + pipeSpace + pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + cornerRadius + pipeSpace*2*((@num-2-i)+1)) + vec1_ylength*(distanceFromWall_y + pipeSpace + pipeSpace*2*(@num-2-i)), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)) + vec1_xlength*(distanceFromWall_y + pipeSpace + pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)) + vec1_ylength*(distanceFromWall_y + pipeSpace + pipeSpace*2*(@num-2-i)), 0]

					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace - pipeSpace*2*(@num-2-i)) + vec1_xlength*(distanceFromWall_y + pipeSpace + cornerRadius + pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace - pipeSpace*2*(@num-2-i)) + vec1_ylength*(distanceFromWall_y + pipeSpace + cornerRadius + pipeSpace*2*(@num-2-i)), 0]
					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace - pipeSpace*2*(@num-2-i)) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace - pipeSpace*2*(@num-2-i)) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)), 0]

					sLineSegments << [sx + vec2_xlength*(long - distanceFromWall_x - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(long - distanceFromWall_x - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*(@num-2-i)), 0]
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + cornerRadius + pipeSpace*2*(@num-2-i)) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + cornerRadius + pipeSpace*2*(@num-2-i)) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - pipeSpace*2*(@num-2-i)), 0]
					
					sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + pipeSpace*2*(@num-2-i)) + vec1_xlength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + pipeSpace*2*(@num-2-i)) + vec1_ylength*(wide - distanceFromWall_y - pipeSpace - cornerRadius - pipeSpace*2*(@num-2-i)), 0]
					if i == @num-2
						# 出口
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace), sy + vec2_ylength*(distanceFromWall_x + pipeSpace), 0]
					else
						sLineSegments << [sx + vec2_xlength*(distanceFromWall_x + pipeSpace + pipeSpace*2*(@num-2-i)) + vec1_xlength*(distanceFromWall_y + pipeSpace + cornerRadius + pipeSpace*2*((@num-2-i)-1)), sy + vec2_ylength*(distanceFromWall_x + pipeSpace + pipeSpace*2*(@num-2-i)) + vec1_ylength*(distanceFromWall_y + pipeSpace + cornerRadius + pipeSpace*2*((@num-2-i)-1)), 0]
					end
				}
			end
		end #end if long > wide
		#画线	
		# draw_line(sLineSegments)
    [sLineSegments]
	end


	#画线
	def draw_line(points)
		model = Sketchup.active_model
		ent = model.entities
		model.start_operation 'add', true
		points.each_cons(2) { |e|
		ent.add_line e[0], e[1]
		}
		model.commit_operation

	end


end

# SpiralLine.new.run




