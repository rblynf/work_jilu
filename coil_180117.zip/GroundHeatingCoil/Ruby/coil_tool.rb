#
# load 'tool_test.rb'


class Coil_Tool

  def initialize(params)
    @model = Sketchup.active_model
    @sel = @model.selection
    @ent = @model.entities
    @params = params
  end

  def reset
    @ip = nil
    @target = nil
    @face = nil
    @edge = nil
    @sel.clear
    @faces_hash.values.map { |face| @ent.erase_entities face.all_connected if face && face.valid? }
    @faces_hash.clear
    @model.abort_operation
    Sketchup.send_action 'selectSelectionTool:'
  end

  def activate
    @model.start_operation "Tool Test", true
    @faces_hash = {}
    @arrow_line_length = 1000.mm # 箭头线长
    @arrow_edge_length = 500.mm # 箭头长

    @controller = FlipPages.new


    @type = @params['布置方式'].to_sym
    obj = defined?(::Struct::CoilParams) ?
        Struct::CoilParams :
        Struct.new('CoilParams',
                   :wall_distance, # 离墙距离
                   :outer_area_spacing, # 外区间距
                   :inner_area_spacing, # 内区间距
                   :outer_special_size, # 外区折回次数
                   :line_lists, # 外墙
                   :corner_radius, # 转角半径
                   :type, # 布置方式
                   :types, # 布置方式集合
                   :limit_length, # 限长
                   :origin, # 起始布置点
                   :coil_vec, # 布置方向
                   :coil_vec_next, # 转弯方向
                   :length, # 长（垂直布置方向）
                   :width) # 宽（平行布置方向）)
    @coil_obj = obj.new
    @coil_obj.type = @type.to_s
    @coil_obj.types ={ :直列型 => 'inline',
                       :往复型 => 'reciprocate',
                       :螺旋型 => 'spiral',
                       :混合型 => 'hybrid' }
    @walls = @params['外墙位置']
    @coil_obj.wall_distance = @params['离墙间距'].to_f.mm # 离墙距离
    @radius = @params['管道直径'].scan(/\d+/)[0].to_f.mm
    @thick = @params['管道壁厚'].to_f.mm
    @n = @params['转角半径'].to_f

    if @params['是否统一']
      @coil_obj.inner_area_spacing = @params['统一间距'].to_f.mm # 内区间距
      @coil_obj.outer_area_spacing = @params['统一间距'].to_f.mm # 外区间距
    else
      @coil_obj.inner_area_spacing = @params['内区间距'].to_f.mm # 内区间距
      @coil_obj.outer_area_spacing = @params['外区间距'].to_f.mm # 外区间距
    end
    @coil_obj.outer_special_size = ((1000.mm - @coil_obj.wall_distance)/@coil_obj.outer_area_spacing).to_i # 外区折回次数
    @coil_obj.corner_radius = (@radius + @thick) * @n # 转角半径
    @coil_obj.limit_length = @params['回路限长'].to_f.m.to_mm # 限长

  end

  def deactivate(view)
    view.invalidate
    reset
  end

  def onCancel(reason, view)
    view.invalidate
    reset
  end

  def getExtents
    bb = @model.bounds
    bb.add(@model.active_view.camera.eye)
    bb.add(@ip.position) if @ip
    bb
  end

  def draw(view)
    view.invalidate
    @ip.draw(view) if @ip
    if @face && @edge
      view_arrow(view) # 指示箭头
      view_coils(view) # 布管视图
    end
  end

  def onMouseMove(flags, x, y, view)
    @ip = view.inputpoint x, y
    @sel.clear; @edge = nil; @face = nil
    if @ip.face
      return unless select_face?(@ip.face)
      @sel.add @ip.face
      @face = @ip.face
      if @ip.edge
        return unless select_edge?(@ip.edge)
        @sel.add @ip.edge
        @edge = @ip.edge
      end
    end
    view.tooltip = @ip.tooltip
    view.invalidate
  end

  def onLButtonDown(flags, x, y, view)
    if @edge && @face
      method = @walls.empty? ? @coil_obj.types[@type] : "wall_#{@walls.size}"
      WarmCoil.send("add_line_#{method}", @points[@controller.index], @coil_obj) unless @points && @points.empty?
      @points.clear
      @model.commit_operation
      @model.start_operation "Tool Test", true
    end

  end

  def onKeyUp(key, repeat, flags, view)
    # 38↑ 40↓ 37←  39→
    case key
      when 9
        @controller.next
      when 38
        @controller.prev
      when 40
        @controller.next
    end
  end

  def onKeyDown(key, repeat, flags, view)

  end

# load 'tool_test.rb'
  private


# 盘管布局
  def view_coils(view)
    @coil_obj.coil_vec = coil_vec
    @coil_obj.origin, @coil_obj.coil_vec_next, @coil_obj.length, @coil_obj.width = WarmCoil.set_up_params(@face, @edge, @ip, coil_vec)

    method = @walls.empty? ? @coil_obj.types[@type] : "wall_#{@walls.size}"
    @coil_obj.line_lists = wall_lists(@walls)

    @points = WarmCoil.send("coil_#{method}", @coil_obj) # unless 'xxx条件'
    return unless @points
    @controller.size = @points.size

    # view.draw_points @coil_obj.origin, 10, 2, "red"
    view.drawing_color = 'red'
    view.line_width = 4
    view.line_stipple = '='
    view.draw_polyline @points[@controller.index]
  end

# 指示箭头
  def view_arrow(view)
    @target = get_target
    return unless edge_vec
    vec_1 = Geom::Vector3d.linear_combination(0.05, coil_vec.reverse, 0.95, edge_vec)
    vec_2 = Geom::Vector3d.linear_combination(0.05, coil_vec.reverse, 0.95, edge_vec.reverse)
    point_1 = @target.offset vec_1, @arrow_edge_length
    point_2 = @target.offset vec_2, @arrow_edge_length
    view.drawing_color = 'green'
    view.line_width = 4
    view.line_stipple = '='
    view.draw2d GL_LINES, [view.screen_coords(@ip.position), view.screen_coords(@target)]
    view.draw2d GL_LINES, [view.screen_coords(@target), view.screen_coords(point_1)]
    view.draw2d GL_LINES, [view.screen_coords(@target), view.screen_coords(point_2)]
  end

# 判断条件合适的面（面向量、属性..）
  def select_face?(face)
    true
  end

# 判断条件合适的线（属性..）
  def select_edge?(edge)
    return true if edge.parent.instance_of? Sketchup::Model
    group = edge.parent.instances[0]
    return false if group && group.attribute_dictionaries && group.attribute_dictionaries['DFC_Coil']
    true
  end

# 箭头点
  def get_target
    vec_coil = edge_vec*Z_AXIS
    point = @ip.position.offset vec_coil, @arrow_line_length

    # 画面判断点是否在选择面范围内，修改
    face = interim_face
    point = @ip.position.offset vec_coil.reverse, @arrow_line_length unless face.classify_point(point) == 1
    # 画面判断点是否在选择面范围内，修改

    point
  end

# 选择线方向
  def edge_vec
    @edge.line[1].transform(@ip.transformation) if @edge && @edge.valid?
  end

# 布管方向
  def coil_vec
    @ip.position.vector_to @target if @target
  end

# 临时面
  def interim_face
    return @face if @face.parent.instance_of? Sketchup::Model
    return @faces_hash[@face] if @faces_hash[@face]
    pts = @face.vertices.collect { |v| v.position.transform(@ip.transformation) }
    face = @ent.add_face pts
    face.all_connected.map { |e| e.hidden = true }
    @faces_hash[@face] = face
    face
  end

# 外墙点向量
# walls = ['外墙一','外墙二','外墙三','外墙四']
  def wall_lists(walls)
    lists = []
    points = @face.outer_loop.vertices.map(&:position).map! { |point| point.transform(@ip.transformation) }

    pts_arrays = points.each_cons(2)

    p1 = points.find { |p| p == @coil_obj.origin }
    points.delete p1

    p2 = nil
    points.map { |p|
      vec = p1.vector_to p
      if vec.samedirection? @coil_obj.coil_vec
        p2 = p
        lists.push [p1, p2] if walls.include? '外墙一'
      end
    }
    points.delete p2

    p3 = nil
    points.map { |p|
      vec = p2.vector_to p
      if vec.samedirection? @coil_obj.coil_vec_next
        p3 = p

        lists.push [p2, p3] if walls.include? '外墙二'
      end
    }
    points.delete p3

    p4 = nil
    points.map { |p|
      vec = p3.vector_to p
      if vec.samedirection? @coil_obj.coil_vec.reverse
        p4 = p
        lists.push [p3, p4] if walls.include? '外墙三'
      end
    }
    lists.push [p4, p1] if walls.include? '外墙四'

    lists
  end

end

class FlipPages

  def initialize(size=0, index=0)
    @size = size
    @index = index
  end

  def size=(size)
    @size = size
  end

  def index
    @index
  end

  def prev
    return 0 if @size == 0
    @index -= 1
    @index = @size - 1 if @index < 0 || @index >= @size
    @index
  end

  def next
    return 0 if @size == 0
    @index += 1
    @index = 0 if @index >= @size
    @index
  end

end

# load 'tool_test.rb'
# class CoilParams < Struct.new :wall_distance, # 离墙距离
#                               :outer_area_spacing, # 外区间距
#                               :inner_area_spacing, # 内区间距
#                               :outer_special_size, # 外区折回次数
#                               :line_lists, # 外墙
#                               :corner_radius, # 转角半径
#                               :type, # 布置方式
#                               :types, # 布置方式集合
#                               :limit_length, # 限长
#                               :origin, # 起始布置点
#                               :coil_vec, # 布置方向
#                               :coil_vec_next, # 转弯方向
#                               :length, # 长（垂直布置方向）
#                               :width # 宽（平行布置方向）
# end unless CoilParams

class WarmCoil
  class << self

    # 接口参数 coil_point, coil_vec_next, length, width
    def set_up_params(face, edge, ip, coil_vec)
      vertex_origin = face.vertices[0]
      reference_point = vertex_origin.position.transform(ip.transformation)
      length = edge.length
      width = 0
      face.edges.map { |edge|
        next unless edge && edge.valid?
        next if edge.length == length
        width = edge.length if edge.length > width
      }
      coil_vec_next, coil_point = coil_vec_origin(reference_point, vertex_origin, face, edge, ip)
      return coil_point, coil_vec_next, length, width
    end

    # coil_vec_next，coil_point
    def coil_vec_origin(reference_point, vertex_origin, face, edge, ip)
      vertex_coil = nil
      if vertex_origin.position.on_line? edge.line # 0,1
        vertex_target = edge.other_vertex vertex_origin
        coil_vec_next = vertex_origin.position.vector_to vertex_target.position

        target = vertex_target.position.transform(ip.transformation)
        dis_origin = reference_point.distance ip.position
        dis_target = target.distance ip.position

        if dis_origin <= dis_target
          vertex_coil = vertex_origin
        else
          vertex_coil = vertex_target
          coil_vec_next.reverse!
        end
      else # 2,3
        vertex_origin_mirror = nil
        face.vertices.map { |vert| next if vert == vertex_origin; vertex_origin_mirror = vert unless vert.common_edge(vertex_origin) }

        vertex_target = edge.other_vertex vertex_origin_mirror
        coil_vec_next = vertex_origin_mirror.position.vector_to vertex_target.position

        reference_point = vertex_origin_mirror.position.transform(ip.transformation)
        target = vertex_target.position.transform(ip.transformation)
        dis_origin = reference_point.distance ip.position
        dis_target = target.distance ip.position

        if dis_origin <= dis_target
          vertex_coil = vertex_origin_mirror
        else
          vertex_coil = vertex_target
          coil_vec_next.reverse!
        end
      end
      return coil_vec_next.transform(ip.transformation), vertex_coil.position.transform(ip.transformation)
    end

    # load 'tool_test.rb'
    # 直列型
    def coil_inline(coil_obj)
      Pipe_line.new.run(coil_obj.wall_distance,
                        coil_obj.outer_area_spacing,
                        coil_obj.inner_area_spacing,
                        coil_obj.outer_special_size,
                        coil_obj.corner_radius,
                        coil_obj.limit_length,
                        coil_obj.origin,
                        coil_obj.coil_vec,
                        coil_obj.coil_vec_next,
                        coil_obj.length,
                        coil_obj.width)
    end

    def add_line_inline(points, coil_obj)
      group = Sketchup.active_model.entities.add_group

      points_ = points.last(6)
      # 结束部分的直线
      group.entities.add_line points_[0], points_[1] # 0-1 第一段
      group.entities.add_line points_[2], points_[3] # 2-3 第二段
      group.entities.add_line points_[4], points_[5] # 4-5 第三段
      # 结束部分的圆弧
      # 1-2 第一段
      line1 = [points_[1], coil_obj.coil_vec_next]
      point1 = points_[2].project_to_line line1
      vec_prev_1 = points_[0].vector_to points_[1]
      vec_1 = vec_prev_1*coil_obj.coil_vec_next
      (vec_1.z < 0) ?
          group.entities.add_arc(point1, coil_obj.coil_vec_next, Z_AXIS, coil_obj.corner_radius, 0.degrees, 90.degrees, 12) :
          group.entities.add_arc(point1, coil_obj.coil_vec_next.reverse, Z_AXIS, coil_obj.corner_radius, 90.degrees, 180.degrees, 12)
      # 3-4 第二段
      line2 = [points_[4], coil_obj.coil_vec_next]
      point2 = points_[3].project_to_line line2
      vec_prev_2 = points_[4].vector_to points_[5]
      vec_2 = vec_prev_2*coil_obj.coil_vec_next
      (vec_2.z < 0) ?
          group.entities.add_arc(point2, coil_obj.coil_vec_next.reverse, Z_AXIS, coil_obj.wall_distance/4, 0.degrees, 90.degrees, 12) :
          group.entities.add_arc(point2, coil_obj.coil_vec_next, Z_AXIS, coil_obj.wall_distance/4, 90.degrees, 180.degrees, 12)

      # 循环部分的半圆
      (1..points.size-6).each_slice(2) { |e|
        next unless e[1]
        i, j = e
        next unless points[i-1] && points[i] && points[j]
        point = Geom.linear_combination(0.5, points[i], 0.5, points[j])
        radius = points[i].distance(points[j])/2
        vec_prev = points[i-1].vector_to points[i]
        vec = vec_prev*coil_obj.coil_vec_next
        arc_vec = (vec.z <0) ? coil_obj.coil_vec_next : coil_obj.coil_vec_next.reverse
        group.entities.add_arc point, arc_vec, Z_AXIS, radius, 0, 180.degrees, 12
      }
      # 循环部分的直线
      (0..points.size-6).each_slice(2) { |e|
        next unless e[1]
        group.entities.add_line points[e[0]], points[e[1]]
      }
      group.set_attribute('DFC_Coil', coil_obj.type, YAML.dump(coil_obj)) # 设置下属性，不被选
    end

    # load 'tool_test.rb'
    # 往复型
    def coil_reciprocate(coil_obj)
      Reciprocate.new.run(coil_obj.wall_distance,
                          coil_obj.outer_area_spacing,
                          coil_obj.inner_area_spacing,
                          coil_obj.outer_special_size,
                          coil_obj.corner_radius,
                          coil_obj.limit_length,
                          coil_obj.origin,
                          coil_obj.coil_vec,
                          coil_obj.coil_vec_next,
                          coil_obj.length,
                          coil_obj.width)
    end

    def add_line_reciprocate(points, coil_obj)
      group = Sketchup.active_model.entities.add_group

      arr_item = []
      arr_arc_1 = [] # 圆弧1
      arr_arc_2 = [] # 圆弧2
      arr_round = [] # 半圆

      size = points.size
      (3..size-1).each_slice(2) { |e|
        next if e.size != 2
        arr_item.push e
      }
      # 最后一个半圆
      if arr_item.size%2 != 0
        i = arr_item.size/2
        item = arr_item[i]
        arr_item.delete item
        arr_round.push item
      end

      # 分类
      count = 0
      loop {
        break if arr_item.empty?
        if count%2 ==0
          item = arr_item.shift
          arr_arc_1.push item if item
          item = arr_item.shift
          arr_arc_2.push item if item
          item = arr_item.pop
          arr_round.push item if item
          count +=1
        else
          item = arr_item.shift
          arr_round.push item if item
          item = arr_item.pop
          arr_arc_2.push item if item
          item = arr_item.pop
          arr_arc_1.push item if item
          count+=1
        end
      }
      arr_round.sort!
      arr_arc_1.sort!
      arr_arc_2.sort!

      # 圆弧1
      count = nil
      arr_arc_1.map { |e|
        i, j = e
        line1 = [points[i], coil_obj.coil_vec_next]
        point1 = points[j].project_to_line line1
        vec_prev_1 = points[i-1].vector_to points[i]
        vec_1 = vec_prev_1*coil_obj.coil_vec_next
        count = (vec_1.z < 0) ? 0 : 1 unless count
        angle = (count == 0) ? 90 : 0
        (vec_1.z < 0) ?
            group.entities.add_arc(point1, coil_obj.coil_vec_next, Z_AXIS, coil_obj.corner_radius, (0+angle).degrees, (90+angle).degrees, 12) :
            group.entities.add_arc(point1, coil_obj.coil_vec_next.reverse, Z_AXIS, coil_obj.corner_radius, (0+angle).degrees, (90+angle).degrees, 12)
      }

      # 圆弧2
      count = nil
      arr_arc_2.map { |e|
        i, j = e
        line1 = [points[j], coil_obj.coil_vec_next]
        point1 = points[i].project_to_line line1
        vec_prev_1 = points[j-1].vector_to points[j]
        vec_1 = vec_prev_1*coil_obj.coil_vec_next
        count = (vec_1.z < 0) ? 0 : 1 unless count
        angle = (count == 0) ? 90 : 0
        (vec_1.z < 0) ?
            group.entities.add_arc(point1, coil_obj.coil_vec_next.reverse, Z_AXIS, coil_obj.corner_radius, (0+angle).degrees, (90+angle).degrees, 12) :
            group.entities.add_arc(point1, coil_obj.coil_vec_next, Z_AXIS, coil_obj.corner_radius, (0+angle).degrees, (90+angle).degrees, 12)
      }

      # 半圆
      arr_round.map { |e|
        i, j = e
        next unless points[i-1] && points[i] && points[j]
        point = Geom.linear_combination(0.5, points[i], 0.5, points[j])
        radius = points[i].distance(points[j])/2
        vec_prev = points[i-1].vector_to points[i]
        vec = vec_prev*coil_obj.coil_vec_next
        arc_vec = (vec.z <0) ? coil_obj.coil_vec_next : coil_obj.coil_vec_next.reverse
        group.entities.add_arc point, arc_vec, Z_AXIS, radius, 0, 180.degrees, 12
      }

      # 循环直线
      points.each_slice(2) { |e|
        next unless e[1]
        group.entities.add_line e[0], e[1]
      }

      group.set_attribute('DFC_Coil', coil_obj.type, YAML.dump(coil_obj)) # 设置下属性，不被选
    end

    # load 'tool_test.rb'
    # 螺旋型
    def coil_spiral(coil_obj)
      SpiralLine.new.run(coil_obj.wall_distance,
                         coil_obj.outer_area_spacing,
                         coil_obj.inner_area_spacing,
                         coil_obj.outer_special_size,
                         coil_obj.corner_radius,
                         coil_obj.limit_length,
                         coil_obj.origin,
                         coil_obj.coil_vec,
                         coil_obj.coil_vec_next,
                         coil_obj.length,
                         coil_obj.width)
    end

    def add_line_spiral(points, coil_obj)
      group = Sketchup.active_model.entities.add_group

      length = (coil_obj.length >= coil_obj.width) ? coil_obj.width : coil_obj.length
      count = ((length - coil_obj.wall_distance*2)/(coil_obj.inner_area_spacing*2)).to_i
      remian = (length - coil_obj.wall_distance*2 - coil_obj.inner_area_spacing*2*count)

      if count%2 == 0 || (remian >= coil_obj.inner_area_spacing*3/2 && count%2 != 0)
        c = points.size/2 # 中间半圆位置
        (1..points.size).each_slice(2) { |e|
          next unless e[1]
          i, j = e
          next unless points[j]
          if i == c || i == c + 2 # 半圆
            point = Geom.linear_combination(0.5, points[i], 0.5, points[j])
            vec1 = points[i].vector_to points[i-1]
            vec2 = points[i].vector_to points[j]
            vec = vec1*vec2
            (vec.z > 0) ?
                group.entities.add_arc(point, vec2, Z_AXIS, (points[i].distance points[j])/2, 0, 180.degrees, 12) :
                group.entities.add_arc(point, vec2.reverse, Z_AXIS, (points[i].distance points[j])/2, 0, 180.degrees, 12)
          else # 圆弧
            vec1 = points[i].vector_to points[i-1]
            vec2 = points[j].vector_to points[j+1]
            vec = vec1*vec2
            line = [points[j], vec1]
            point = points[i].project_to_line line
            (vec.z > 0) ?
                group.entities.add_arc(point, vec1.reverse, Z_AXIS, coil_obj.corner_radius, 0.degrees, 90.degrees, 12) :
                group.entities.add_arc(point, vec1, Z_AXIS, coil_obj.corner_radius, 90.degrees, 180.degrees, 12)
          end
        }
      else
        (1..points.size).each_slice(2) { |e|
          next unless e[1]
          i, j = e
          next unless points[j]
          vec1 = points[i].vector_to points[i-1]
          vec2 = points[j].vector_to points[j+1]
          vec = vec1*vec2
          line = [points[j], vec1]
          point = points[i].project_to_line line
          (vec.z > 0) ?
              group.entities.add_arc(point, vec1.reverse, Z_AXIS, coil_obj.corner_radius, 0.degrees, 90.degrees, 12) :
              group.entities.add_arc(point, vec1, Z_AXIS, coil_obj.corner_radius, 90.degrees, 180.degrees, 12)
        }
      end


      # 循环直线
      points.each_slice(2) { |e|
        next unless e[1]
        group.entities.add_line e[0], e[1]
      }

      group.set_attribute('DFC_Coil', coil_obj.type, YAML.dump(coil_obj)) # 设置下属性，不被选
    end

    # load 'tool_test.rb'
    # 混合型
    def coil_hybrid(coil_obj)
      p '混合型'
    end

    def add_line_hybrid(points, coil_obj)
      group = Sketchup.active_model.entities.add_group

      points.each_cons(2) { |e|
        next unless e[1]
        group.entities.add_line e[0], e[1]
      }

      group.set_attribute('DFC_Coil', coil_obj.type, YAML.dump(coil_obj)) # 设置下属性，不被选
    end

    # load 'tool_test.rb'
    # 一面外墙
    def coil_wall_1(coil_obj)
      WaiqiangLine.new.run(coil_obj.wall_distance,
                         coil_obj.outer_area_spacing,
                         coil_obj.inner_area_spacing,
                         coil_obj.outer_special_size,
                         coil_obj.coil_vec,
                         coil_obj.coil_vec_next,
                         coil_obj.line_lists,
                         coil_obj.corner_radius,
                         coil_obj.limit_length,
                         coil_obj.origin,
                         coil_obj.length,
                         coil_obj.width)
    end

    def add_line_wall_1(points, coil_obj)
      group = Sketchup.active_model.entities.add_group

      points.each_cons(2) { |e|
        next unless e[1]
        group.entities.add_line e[0], e[1]
      }

      group.set_attribute('DFC_Coil', '一面外墙', YAML.dump(coil_obj)) # 设置下属性，不被选
    end

    # load 'tool_test.rb'
    # 2面外墙
    def coil_wall_2(coil_obj)
      WaiqiangLine.new.run(coil_obj.wall_distance,
                           coil_obj.outer_area_spacing,
                           coil_obj.inner_area_spacing,
                           coil_obj.outer_special_size,
                           coil_obj.coil_vec,
                           coil_obj.coil_vec_next,
                           coil_obj.line_lists,
                           coil_obj.corner_radius,
                           coil_obj.limit_length,
                           coil_obj.origin,
                           coil_obj.length,
                           coil_obj.width)
    end

    def add_line_wall_2(points, coil_obj)

      group = Sketchup.active_model.entities.add_group

      points.each_cons(2) { |e|
        next unless e[1]
        group.entities.add_line e[0], e[1]
      }

      group.set_attribute('DFC_Coil', '2面外墙', YAML.dump(coil_obj)) # 设置下属性，不被选
    end

    # load 'tool_test.rb'
    # 3面外墙
    def coil_wall_3(coil_obj)
      WaiqiangLine.new.run(coil_obj.wall_distance,
                           coil_obj.outer_area_spacing,
                           coil_obj.inner_area_spacing,
                           coil_obj.outer_special_size,
                           coil_obj.coil_vec,
                           coil_obj.coil_vec_next,
                           coil_obj.line_lists,
                           coil_obj.corner_radius,
                           coil_obj.limit_length,
                           coil_obj.origin,
                           coil_obj.length,
                           coil_obj.width)
    end

    def add_line_wall_3(points, coil_obj)

      group = Sketchup.active_model.entities.add_group

      points.each_cons(2) { |e|
        next unless e[1]
        group.entities.add_line e[0], e[1]
      }

      group.set_attribute('DFC_Coil', '3面外墙', YAML.dump(coil_obj)) # 设置下属性，不被选
    end

    # load 'tool_test.rb'
    # 4面外墙
    def coil_wall_4(coil_obj)
      WaiqiangLine.new.run(coil_obj.wall_distance,
                           coil_obj.outer_area_spacing,
                           coil_obj.inner_area_spacing,
                           coil_obj.outer_special_size,
                           coil_obj.coil_vec,
                           coil_obj.coil_vec_next,
                           coil_obj.line_lists,
                           coil_obj.corner_radius,
                           coil_obj.limit_length,
                           coil_obj.origin,
                           coil_obj.length,
                           coil_obj.width)
    end

    def add_line_wall_4(points, coil_obj)

      group = Sketchup.active_model.entities.add_group

      points.each_cons(2) { |e|
        next unless e[1]
        group.entities.add_line e[0], e[1]
      }

      group.set_attribute('DFC_Coil', '4面外墙', YAML.dump(coil_obj)) # 设置下属性，不被选
    end

    # 外部转内部
    def transform_inner_obj(obj, entity)
      return obj unless entity
      tran = Geom::Transformation.new
      trans = entity.transformation*tran
      obj.transform trans.inverse
    end


  end
end

# load 'tool_test.rb'
# Sketchup.active_model.select_tool Coil_Tool.new

