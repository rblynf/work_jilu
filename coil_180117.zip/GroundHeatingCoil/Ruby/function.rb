module SmallPipe
	def self.printVal(params)
		# 对数据处理	
		# puts params
	end
	
end	