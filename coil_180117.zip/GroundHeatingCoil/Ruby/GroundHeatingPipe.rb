# # require File.join(DFC_BIM::PATH.getPath(:Core, :Mep, "GroundHeatingCoil", "Ruby")+'/function.rb')
# module GroundHeatingPipe
#   # MyUI_PATH = DFC_BIM::PATH.getPath(:Core, :Mep, "GroundHeatingCoil", "UI")
#   # MyData_PATH = DFC_BIM::PATH.getPath(:Core, :Mep, "GroundHeatingCoil", "Data")
#   def self.MyDialog
#     # include DFC_BIM::SYSTEM
#     # puts "path:#{MyData_PATH}"
#     # DATA_PATH = PathHelper[:Data]
#     # 编码
#     @dir = File.dirname(__FILE__).encode("UTF-8")
#     @dirname = File.dirname(__FILE__).encode("UTF-8")
#
#     @dialog = UI::WebDialog.new("地暖盘管工具", true, "机电", 900, 700, 140, 250, true)
#
#     #地暖管小窗口
#     @dialogDng = UI::WebDialog.new("地暖盘管设置", true, "parme", 576.mm, 115.mm, 150, 150, true)
#     @dialogDng.set_url (MyUI_PATH + "/html/srqSet.html")
#     #地暖管颜色
#     @dialogColor = UI::WebDialog.new("颜色定义", true, "color", 610.mm, 360.mm, 150, 150, true)
#     @dialogColor.set_url (MyUI_PATH + "/html/color.html")
#     # 地暖管散热器 布置小窗口
#
#     @dialog.add_action_callback('ruby_cancle') { |dialog|
#       if @dialogDng.visible?
#         show_cancel = "show_cancel()"
#         @dialogDng.execute_script(show_cancel)
#       end
#       dialog.close
#     }
#     #关闭窗口触发
#     @dialog.set_on_close {
#       if @dialog.visible?
#          cancel = "show_aaa()"
#          @dialog.execute_script(cancel)
#       end
#       # 关闭窗口
#       if @dialogDng.visible?
#          show_cancel = "show_cancel()"
#          @dialogDng.execute_script(show_cancel)
#       end
# 	  if @dialogColor.visible?
# 		 @dialogColor.close
# 	  end
#     }
#     #预览框本地图片
#     @dialog.add_action_callback('YL_BD_max') { |dialog, params|
#       # path = File.join(@dir+ "/caizhi/")
#       bd_id = params
#       path = File.join(File.join(MyUI_PATH+"/image/"))
#       dataPath = DFC_BIM::PATH.getPath(:DefaultData, 'Mep', '暖通','管道部分')
#       # puts path
#       if File.exist?(File.join(path, "caizhi"))
#         path = File.join(path, "caizhi")
#       end
#       chosen_image = UI.openpanel("选择暖通材质", dataPath, "材质文件|*.jpg;*.png;*.skp;|")
#       if chosen_image
#         chosen_image.gsub!('\\', '/')
#         productId = File.basename(chosen_image)[0...-4]
#         show_image1 = %Q{
# 					show_YL_image('#{chosen_image}');
# 				}
#         @dialog.execute_script(show_image1)
#       end
#     }
#
#     # 重置按钮 设置页面的高度
#     @dialog.add_action_callback('set_winSize') { |dialog, params|
#       dialog.set_size(705, 563);
#     }
#     @dialog.add_action_callback('srq_set_size') { |dialog, params|
#       dialog.set_size(705, 860);
#     }
#     # 地暖管取消功能 数组
#     @dialog.add_action_callback('ruby_map') { |dialog, params|
#       data = JSON.parse params
#       name = data["键"]
#       value = data["值"]
#       model = Sketchup.active_model
#       model.set_attribute('map_parameter', name, value)
#     }
#     # 地暖管取消按钮
#     @dialog.add_action_callback('cancel_btn') { |dialog|
#       show_cancel()
#     }
#     # 地暖管取消功能 数组删除
#     @dialog.add_action_callback('delete_map') { |dialog, params|
#       model = Sketchup.active_model
#       map_attr = model.attribute_dictionaries['map_parameter']
#       if map_attr != nil
#         map_attr.delete_key(params)
#         hash = Array.new
#         map_attr.each { |key, value|
#           hash << key
#         }
#         b = []
#         hash.each { |k|
#           k = k.to_i
#           b.push k
#         }
#         b.sort!
#         b.each_with_index do |key|
#           if params.to_i < key.to_i
#             names = key.to_s
#             key = key.to_i - 1
#             name = key.to_s
#             param = model.get_attribute('map_parameter', names)
#             model.set_attribute('map_parameter', name, param)
#           end
#         end
#       end
#       #show 取消的数组
#       show_cancel()
#     }
#     # 地暖管图片显示
#     @dialog.add_action_callback('HD_conduit_show_pic') { |dialog|
#       # puts '更改地暖管图片'
#       show_conduit_pic()
#     }
#     # 替换散热器图片 保存数据
#     @dialog.add_action_callback('ruby_pic_update') { |dialog, params|
#       param = JSON.parse params
#       # puts param
#       name = param["替换前"]
#       value = param["替换后"]
#       model = Sketchup.active_model
#       model.set_attribute('pic_parameter', name, value)
#     }
#
#
#     #地暖管参数恢复
#     @dialog.add_action_callback('ruby_recover') { |dialog, params|
#       js = JSON.parse params
#       name = js["管道编号"]
#       model = Sketchup.active_model
#       val = model.get_attribute('conduit_parameter', name)
#       if val==nil
#         # puts "第一次存默认"
#         # show_data = "show_default()"
#         # @dialog.execute_script(show_data)
#       else
#         va = JSON.parse(val)
#         SmallPipe.printVal(va)
#         show_data = "show_param(#{val})"
#         @dialog.execute_script(show_data)
#       end
#     }
#
#     # 地暖参数取值
#     @dialog.add_action_callback('ruby_value') { |dialog, params|
#       js = JSON.parse params
#       name = js["管道编号"]
#       model = Sketchup.active_model
#       value = model.get_attribute('conduit_parameter', name)
#       if value==nil
#         # puts "默认"
#         show_data = "show_default()"
#         @dialog.execute_script(show_data)
#       else
#         # puts "数据处理"
#         param = JSON.parse value
#         aa = Hash.new
#         param.each { |key, val|
#           if key == "管道直径"
#             key = "管道外径"
#           end
#           if key == "管道厚度"
#             key = "管道内径"
#             if param["管道直径"][0..1] == "DE" || param["管道直径"][0..1] == "DN" #de20*2.8
#               val = param["管道直径"][2..5].to_f - val.to_f * 2
#             end
#           end
#           aa[key] = val.to_s
#         }
#       end
#     }
#     #地暖管显示小窗口
#     @dialog.add_action_callback('ruby_win') { |dialog, params|
#       show_window(params)
#       @dialog.close
#     }
#     #地暖管小窗口 切换编号 查询value 显示在小窗口
#     @dialogDng.add_action_callback('ruby_id') { |dialog, params|
#       model = Sketchup.active_model
#       value = model.get_attribute('conduit_parameter', params)
#       val = JSON.parse(value)
#       SmallPipe.printVal(val)
#       show_data = "show_winId(#{value})"
#       @dialogDng.execute_script(show_data)
#     }
#     #地暖管小窗口 切换直径 修改直径厚度
#     @dialogDng.add_action_callback('ruby_updateSmall') { |dialog, params|
#       param = JSON.parse params
#       param1 = param["管道编号"]
#       param2 = param["管道直径"]
#       param3 = param["管道厚度"]
#       model = Sketchup.active_model
#       value = model.get_attribute('conduit_parameter', param1)
#       value = JSON.parse value
#       value["管道直径"] = param2
#       value["管道厚度"] = param3
#       value = value.to_json
#       model.set_attribute('conduit_parameter', param1, value)
#       values = model.get_attribute('conduit_parameter', param1)
#       val = JSON.parse(values)
#       SmallPipe.printVal(val)
#     }
#     #地暖管小窗口 厚度修改 输出值
#     @dialogDng.add_action_callback('ruby_updateThick') { |dialogDng, params|
#       param = JSON.parse params
#       param1 = param["管道编号"]
#       param2 = param["管道厚度"]
#       model = Sketchup.active_model
#       value = model.get_attribute('conduit_parameter', param1)
#       value = JSON.parse value
#       value["管道厚度"] = param2
#       value = value.to_json
#       model.set_attribute('conduit_parameter', param1, value)
#       values = model.get_attribute('conduit_parameter', param1)
#       val = JSON.parse(values)
#       SmallPipe.printVal(val)
#     }
#     #地暖管小窗口 单击显示小窗口参数
#     @dialogDng.add_action_callback('ruby_showPram') { |dialogDng, params|
#       $conduitToDraw = "地暖盘管绘制"
#       puts $conduitToDraw
#     }
#     #地暖管 关闭小窗口 打开大窗口 并显示系统参数？回传是dialogDng 还是dialog？
#     @dialogDng.add_action_callback('ruby_system') { |dialog, params|
#       model = Sketchup.active_model
#       # val = model.get_attribute('conduit_parameter', params)
#       attrdict = model.attribute_dictionary('conduit_parameter')
#       checkId = params[3, 2]
#       hash = Array.new
#       attrdict.each { |key, value|
#         hash << key
#       }
#       b = []
#       hash.each { |k|
#         k = k[3, 2].to_i
#         b.push k
#       }
#       b.sort!
#       @dialog.show {
#         b.each_with_index do |key|
#           key = "DN-" + key.to_s
#           value = model.get_attribute('conduit_parameter', key)
#           show_data = "show_page('#{key}','#{value}','#{checkId}')"
#           @dialog.execute_script(show_data)
#         end
#         # 显示到参数设置页面
#         # show_data = "show_winSys(#{val})"
#         # @dialog.execute_script(show_data)
#       }
#     }
#     #地暖管的颜色页面开启
#     @dialog.add_action_callback('ruby_color') { |dialog, params|
#       show_color(params)
#     }
#     @dialogColor.add_action_callback('ruby_colorOK') { |dialogColor, params|
#       @dialogColor.close
#     }
#     @dialogColor.add_action_callback('ruby_changeColor') { |dialog, params|
#       show_data = "colorOK('#{params}')"
#       @dialog.execute_script(show_data)
#     }
#     @dialogColor.add_action_callback('ruby_coclorCancel') { |dialog|
#       @dialogColor.close
#     }
#     @dialog.add_action_callback('ruby_color2') { |dialog, params|
#       show_color2(params)
#     }
#     @dialogColor.add_action_callback('ruby_changeColor2') { |dialog, params|
#       show_data = "colorOK2('#{params}')"
#       @dialog.execute_script(show_data)
#     }
#     #	散热器参数取值
#     @dialog.add_action_callback('ruby_srq_value') { |dialog, params|
#       model = Sketchup.active_model
#       model.set_attribute('srq_parameter', "散热器", params)
#     }
#     @dialog.add_action_callback('show_srq_data') { |dialog, params|
#       # show散热器
#       model = Sketchup.active_model
#       srq_attrdict = model.attribute_dictionary('srq_parameter')
#       if srq_attrdict == nil
#         # puts "默认srq参数"
#       else
#         puts srq_attrdict.values
#         value = srq_attrdict.values
#         show_params = "show_srq(#{value})"
#         @dialog.execute_script(show_params)
#       end
#     }
#     #	散热器	布置操作
#     @dialog.add_action_callback('ruby_assignSet') { |dialogSrq, params|
#       SmallPipe.printVal(params)
#       dataPath = DFC_BIM::PATH.getPath(:DefaultData, 'Mep', '暖通', '管道部分', '散热器')
#       x = DFC_BIM::Mep::FileInformation.getHashData(dataPath).to_json
#       if @dialogSrq.visible?
#         @dialogSrq.execute_script(%Q{
# 			  srqAssignSet(#{x},#{params});
# 		  })
#       else
#         @dialogSrq.show {
# 			@dialogSrq.execute_script(%Q{
# 				srqAssignSet(#{x},#{params});
# 			})
#         }
#       end
#       @dialog.close
#     }
#     # 页面按钮事件
#     @dialog.add_action_callback('ruby_draw') { |dialog, params|
#       DFC_BIM::Mep::ArrangeFileNew.new.arrange_file_new
#       # puts '绘制'
#     }
#     @dialog.add_action_callback('ruby_pic_set') { |dialog, params|
#       # p params
#       # puts params
#       # puts '保存。'
#       model = Sketchup.active_model
#       model.set_attribute('srq_parameter', "散热器", params)
#       DFC_BIM::Mep::SaveParams.new_dialog(params,
#                                           DFC_BIM::HVAC,
#                                           DFC_BIM::HVAC_PIPELINE,
#                                           DFC_BIM::HVAC_HEAT_SINK)
#     }
#     @dialog.add_action_callback('ruby_import') { |dialog, params|
#       # p params
#       # puts '导入'
#       DFC_BIM::Mep::ArrangeImport.new(params).arrange_import(DFC_BIM::HVAC_HEAT_SINK, [DFC_BIM::HVAC,
#                                                                                        DFC_BIM::HVAC_PIPELINE,
#                                                                                        DFC_BIM::HVAC_HEAT_SINK])
#     }
#     @dialog.add_action_callback('ruby_pic_legend') { |dialog, params|
#       puts '图例'
#     }
#     @dialog.add_action_callback('ruby_pic_quit') { |dialog, params|
#       Sketchup.active_model.select_tool DFC_BIM::Mep::ArrangeBasicPoint.new
#       # puts 'exit'
#     }
#     # 布置 小窗口按钮事件
#     @dialogSrq.add_action_callback('HD_srqSet_buzhi') { |dialogSrq, params|
#       DFC_BIM::Mep::ArrangeStyle.new(JSON.parse(params), [DFC_BIM::HVAC,
#                                                           DFC_BIM::HVAC_PIPELINE,
#                                                           DFC_BIM::HVAC_HEAT_SINK]).arrange_fix_up(DFC_BIM::HVAC_HEAT_SINK)
#     }
#     @dialogSrq.add_action_callback('HD_srqSet_shiqu') { |dialogSrq, params|
#       DFC_BIM::Mep::ArrangeStyle.new(JSON.parse(params), [DFC_BIM::HVAC,
#                                                           DFC_BIM::HVAC_PIPELINE,
#                                                           DFC_BIM::HVAC_HEAT_SINK]).arrange_pick_up(DFC_BIM::HVAC_HEAT_SINK)
#     }
#     @dialogSrq.add_action_callback('HD_srqSet_srqSet') { |dialogSrq, params|
#
#       @dialog.show {
#         show_data = "show_srqData('#{params}')"
#         @dialog.execute_script(show_data)
#       }
#       @dialogSrq.close
#       # puts 'exit'
#     }
#     @dialogSrq.add_action_callback('HD_srqSet_close') { |dialogSrq, params|
#       @dialogSrq.close
#     }
#
#
#     # 导入HTML文件
#     @dialog.set_file MyUI_PATH+"/html/index.html"
#
#     # 加载完页面 就show
#     @dialog.add_action_callback('ruby_back') { |dialog|
#       if @dialogDng.visible?
#
#       else
#         # show地暖管
#         model = Sketchup.active_model
#         attrdict = model.attribute_dictionary('conduit_parameter')
#         if attrdict == nil
#           # puts 123
#         else
#           #初始加载 页面会清空模型空间的值(保留第一行)	-->解决10以上数据
#           hash = Array.new
#           attrdict.each { |key, value|
#             hash << key
#           }
#           b = []
#           hash.each { |k|
#             k = k[3, 2].to_i
#             b.push k
#           }
#           b.sort!
#           b.each_with_index do |key|
#             key = "DN-" + key.to_s
#             value = model.get_attribute('conduit_parameter', key)
#             show_data = "show_page('#{key}','#{value}','#{1}')"
#             @dialog.execute_script(show_data)
#           end
#         end
#         #show 取消的数组
#         show_cancel
#       end
#     }
#  end
#
#   def self.show()
#     self.MyDialog
# 	if not @dialog.visible?
# 	    @dialog.show {
# 			@dialog.execute_script("get_panel_size()");
# 		}
# 	end
#   end
#
#   def self.show_window(params)
#     #所有参数的 页面关闭  显示小窗口 js给页面传递参数
#     model = Sketchup.active_model
#     attrdict = model.attribute_dictionary('conduit_parameter')
#     attrdict.each { |key, val|
#       if key == "DN-"+params
#         va = JSON.parse(val)
#         SmallPipe.printVal(va)
#       end
#     }
#     #判断小窗口是否已经打开 如果打开也执行里面js
#     if @dialogDng.visible?
#       attrdict.each { |key, val|
#         show_params = "show_setParam('#{key}','#{val}','#{params}')"
#         @dialogDng.execute_script(show_params)
#       }
#     else
#       @dialogDng.show {
#         @dialogDng.set_size(555, 110)
#         attrdict.each { |key, val|
#           show_params = "show_setParam('#{key}','#{val}','#{params}')"
#           @dialogDng.execute_script(show_params)
#         }
#       }
#     end
#   end
#
#   def self.show_color(params)
#     @dialogColor.show {
#       @dialogColor.set_size(565, 362)
#       show_data = "colorSet('#{params}')"
#       @dialogColor.execute_script(show_data)
#     }
#   end
#
#   def self.show_color2(params)
#     @dialogColor.show {
#       @dialogColor.set_size(565, 362)
#       show_data = "colorSet2('#{params}')"
#       @dialogColor.execute_script(show_data)
#     }
#   end
#
#   def self.show_conduit_pic()
#     # show图片
#     model = Sketchup.active_model
#     attr = model.attribute_dictionary('pic_parameter')
#     if attr == nil
#       # puts "默认图片"
#     else
#       attr.each { |key, value|
#         show_par = "show_update_pic('#{key}','#{value}')"
#         @dialog.execute_script(show_par)
#       }
#     end
#   end
#
#   def self.show_cancel()
#     model = Sketchup.active_model
#     #show 取消的数组
#     map_attrdict = model.attribute_dictionary('map_parameter')
#     if map_attrdict != nil
#       # puts "show"
#       map_attrdict.each { |key, val|
#         show_params = "show_map('#{key}','#{val}')"
#         @dialog.execute_script(show_params)
#       }
#     end
#   end
# end
# #load "F:/test/test.rb"
# #UI::Dialog.new().show