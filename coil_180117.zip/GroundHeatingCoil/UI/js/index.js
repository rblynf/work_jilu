attr_value = null;
$(function(){
	$("#pipe_material").trigger("change");
	unify_click();
	update_pic();
	loop_change();
});
$("#pipe_material").change(function(){
	material = $(this).val();
	pressure = $("#pipe_pressure").val();
	diameter = $("#pipe_diameter").val();
	if(this.value == "自定义"){
		var top = $("#pipe_material").offset().top;
		var left = $("#pipe_material").offset().left;
		$("#HD_zdy").show();
		$("#HD_zdy").val("");
		$("#HD_zdy").offset({top:top+1,left:left+1});
		$("#HD_id").val("pipe_material");
	}
	change_thick(material,pressure,diameter);
});
$("#pipe_pressure").change(function(){
	material = $("#pipe_material").val();
	pressure = $(this).val();
	diameter = $("#pipe_diameter").val();
	if(this.value == "自定义"){
		var top = $(this).offset().top;
		var left = $(this).offset().left;
		$("#HD_zdy").show();
		$("#HD_zdy").val("");
		$("#HD_zdy").offset({top:top+1,left:left+1});
		$("#HD_id").val("pipe_pressure");
	}
	change_thick(material,pressure,diameter);
});
$("#pipe_diameter").change(function(){
	material = $("#pipe_material").val();
	pressure = $("#pipe_pressure").val();
	diameter = $(this).val();
	if(this.value == "自定义"){
		var top = $(this).offset().top;
		var left = $(this).offset().left;
		$("#HD_zdy").show();
		$("#HD_zdy").val("");
		$("#HD_zdy").offset({top:top+1,left:left+1});
		$("#HD_id").val("pipe_diameter");
	}
	change_thick(material,pressure,diameter);
});
$("#assign").change(function(){
	update_pic();
});

$("#material_del").click(function(){ 
	var val = $("#pipe_material").val();
	$("#pipe_material option").each(function(i,o){
		if(o.value == val){
			$("#pipe_material option[value='"+val+"']").remove();
			$("#pipe_material").trigger("change");
		}
	});
});
$("#diameter_del").click(function(){ 
	var val = $("#pipe_diameter").val();
	$("#pipe_diameter option").each(function(i,o){
		if(o.value == val){
			$("#pipe_diameter option[value='"+val+"']").remove();
			$("#pipe_diameter").trigger("change");
		}
	});
});
$("#pressure_del").click(function(){ 
	var val = $("#pipe_pressure").val();
	$("#pipe_pressure option").each(function(i,o){
		if(o.value == val){
			$("#pipe_pressure option[value='"+val+"']").remove();
			$("#pipe_pressure").trigger("change");
		}
	});
});

$("#loop_length").mousemove(function(){
	if(this.value < 90){
		$(this).removeAttr("title");
	}else if(this.value > 90 && this.value < 120){
		$("#loop_length").attr("title","管路偏长，是否布置？");
	}else if(this.value > 120){
		$("#loop_length").attr("title","管路太长，无法布置！");
	}
});

function unify_click(){
	if($("#unify").is(":checked")){
		$("#unite").attr("disabled",false);
		$("#HD_out").attr("disabled",true);
		$("#HD_inner").attr("disabled",true);
	}else{
		$("#unite").attr("disabled",true);
		$("#HD_out").attr("disabled",false);
		$("#HD_inner").attr("disabled",false);
	}
}

function update_pic(){
	if($("#assign").val() == "螺旋型"){
		$("#HD_imgSet").attr("src","../image/螺旋型.jpg");
	}else if($("#assign").val() == "往复型"){
		$("#HD_imgSet").attr("src","../image/往复型.jpg");
	}else if($("#assign").val() == "直列型"){
		$("#HD_imgSet").attr("src","../image/直列型.jpg");
	}else if($("#assign").val() == "混合型"){
		$("#HD_imgSet").attr("src","../image/混合型.jpg");
	}
}

function loop_change(){
	var val = $("#sys_num").val();
	$("#HD_loop").val(val+"-");
}

function change_thick(material,pressure,diameter){
	if(material == 'PE-RT管'){
		if(pressure == '0.4MPa'){
			$(".pipe_s").val("6.3");
			if(diameter == 'Φ16'){
				$(".pipe_thick").attr("disabled",true);
				$(".pipe_thick").val("");
			}else if(diameter == 'Φ20'){
				$(".pipe_thick").attr("disabled",true);
				$(".pipe_thick").val("");
			}else if(diameter == 'Φ25'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("2");
			}else{
//				$(".pipe_thick").attr("disabled",false);
			}
		}else if(pressure == '0.6MPa'){
			$(".pipe_s").val("5");
			if(diameter == 'Φ16'){
				$(".pipe_thick").attr("disabled",true);
				$(".pipe_thick").val("");
			}else if(diameter == 'Φ20'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("2");
			}else if(diameter == 'Φ25'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("2.3");
			}else{
//				$(".pipe_thick").attr("disabled",false);
			}
		}else if(pressure == '0.8MPa'){
			$(".pipe_s").val("4");
			if(diameter == 'Φ16'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("2");
			}else if(diameter == 'Φ20'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("2.3");
			}else if(diameter == 'Φ25'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("2.8");
			}else{
//				$(".pipe_thick").attr("disabled",false);
			}
		}else{
//			$(".pipe_thick").attr("disabled",false);
		}
	}else if(material == 'PE-X管'){
		if(pressure == '0.4MPa'){
			$(".pipe_s").val("6.3");
			if(diameter == 'Φ16'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.8");
			}else if(diameter == 'Φ20'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.9");
			}else if(diameter == 'Φ25'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.9");
			}else{
//				$(".pipe_thick").attr("disabled",false);
			}
		}else if(pressure == '0.6MPa'){
			$(".pipe_s").val("6.3");
			if(diameter == 'Φ16'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.8");
			}else if(diameter == 'Φ20'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.9");
			}else if(diameter == 'Φ25'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.9");
			}else{
//				$(".pipe_thick").attr("disabled",false);
			}
		}else if(pressure == '0.8MPa'){
			$(".pipe_s").val("4");
			if(diameter == 'Φ16'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.8");
			}else if(diameter == 'Φ20'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.9");
			}else if(diameter == 'Φ25'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("2.3");
			}else{
//				$(".pipe_thick").attr("disabled",false);
			}
		}else{
//				$(".pipe_thick").attr("disabled",false);
		}
	}else if(material == 'PE-B管'){
		if(pressure == '0.4MPa'){
			$(".pipe_s").val("10");
			if(diameter == 'Φ16'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.3");
			}else if(diameter == 'Φ20'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.3");
			}else if(diameter == 'Φ25'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.3");
			}else{
//				$(".pipe_thick").attr("disabled",false);
			}
		}else if(pressure == '0.6MPa'){
			$(".pipe_s").val("8");
			if(diameter == 'Φ16'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.3");
			}else if(diameter == 'Φ20'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.3");
			}else if(diameter == 'Φ25'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.5");
			}else{
//				$(".pipe_thick").attr("disabled",false);
			}
		}else if(pressure == '0.8MPa'){
			$(".pipe_s").val("6.3");
			if(diameter == 'Φ16'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.3");
			}else if(diameter == 'Φ20'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.3");
			}else if(diameter == 'Φ25'){
				$(".pipe_thick").attr("disabled",false);
				$(".pipe_thick").val("1.5");
			}else{
//				$(".pipe_thick").attr("disabled",false);
			}
		}else{
//			$(".pipe_thick").attr("disabled",false);
		}
	}else if(material == "自定义"){
//		$(".pipe_thick").attr("disabled",false);
	}
}
$("#HD_zdy").blur(function(){
	$("#HD_zdy").hide();
	$("<option value='"+this.value+"'>"+this.value+"</option>").insertBefore($("#"+$("#HD_id").val()).find("option").last());
	$("#"+$("#HD_id").val()).val(this.value);
});
$(".btn_ok").click(function(){
	var param = get_attr();
	var params = JSON.stringify(param);
	window.location = "skp:save_attr@"+params; 
	window.location = "skp:mainWin@";
});
$(".btn_quit").click(function(){
	window.location = "skp:mainWin@";
});

function is_num(obj){
	if(isNaN(obj.value)){
		alert("请输入数字!");
		$(obj).focus();
		$(obj).val(obj.value);
	}
}

function back_light(){
	var param = get_setPage();
	var params = JSON.stringify(param);
	window.location = "skp:save_Set@"+params;
	window.location = "skp:attrSet@"+$("#sys_num").val();
}

function add_shiqu(){
	var hash = {}
	if(attr_value==null){
		alert("请设置管道属性信息!");
		return;
	}
	var param2 = get_setPage();
	$.each(attr_value,function(i,obj){
		hash[i]=obj;
	});
	$.each(param2,function(i,obj){
		hash[i]=obj;
	});
	//alert(JSON.stringify(hash));
	window.location = "skp:coil_tool@"+JSON.stringify(hash);
}
function close_lightSet(){
	window.location = "skp:ruby_cancle@";
}
$("#HD_moren").click(function(){
	$("#HD_text").css("background-color", "#ff8000");
	$("#HD_conduit_pipe_text").val("#ff8000");
});
$("#HD_moren2").click(function(){
	$("#HD_text2").css("background-color", "#ff8000");
	$("#HD_conduit_pipe_text2").val("#ff8000");
});
//颜色按钮
$("#HD_conduit_pipe").click(function(){
	window.location="skp:ruby_color@" + $("#HD_conduit_pipe_text").val();
});
$("#HD_conduit_pipe2").click(function(){
	window.location="skp:ruby_color2@" + $("#HD_conduit_pipe_text2").val();
});
function colorOK(all){
    $("#HD_conduit_pipe_text").val(all);
    $("#HD_text").css("background-color","#"+all);
}
function colorOK2(all){
	$("#HD_conduit_pipe_text2").val(all);
	$("#HD_text2").css("background-color","#"+all);
}
/*颜色修改方法*/
function colorSet(data){
	$('#color_div').jPicker(
	/**/
	  {
	    color:{
	      mode: 'h', 
	      active: new $.jPicker.Color({ hex: data })
	    },
	    images:
	    {
	      clientPath: '../image/', // Path to image files
	    }
	  },
	    function(color, context){       //确认按钮事件
		    window.location = "skp:ruby_colorOK@" + color.val('all').hex;
		    $("#color_div").remove();
	    },
	    function(color, context){       //颜色改变事件
	    	var all = color.val('all');
	    	window.location = "skp:ruby_changeColor@" + all.hex;
	    },
	    function(color, context){       //取消按钮事件
		    var value = $('.Current').css('background-color');
		    window.location = "skp:ruby_colorCancel@";
		    //不理解	注释掉不影响关闭 	rgb2hex未定义
		    /*$("#TS_MC_color_text").val(rgb2hex(value));
		    $("#TS_MC_color").css("background-color","#"+rgb2hex(value));*/
		    $("#color_div").remove();
		}
	);
}
function colorSet2(data){
	$('#color_div').jPicker(
	/**/
	  {
	    color:{
	      mode: 'h', 
	      active: new $.jPicker.Color({ hex: data })
	    },
	    images:
	    {
	      clientPath: '../image/', // Path to image files
	    }
	  },
	    function(color, context){       //确认按钮事件
		    window.location = "skp:ruby_colorOK@" + color.val('all').hex;
		    $("#color_div").remove();
	    },
	    function(color, context){       //颜色改变事件
	    	var all = color.val('all');
	    	window.location = "skp:ruby_changeColor2@" + all.hex;
	    },
	    function(color, context){       //取消按钮事件
		    var value = $('.Current').css('background-color');
		    window.location = "skp:ruby_colorCancel@";
		    //不理解	注释掉不影响关闭 	rgb2hex未定义
		    /*$("#TS_MC_color_text").val(rgb2hex(value));
		    $("#TS_MC_color").css("background-color","#"+rgb2hex(value));*/
		    $("#color_div").remove();
		}
	);
}

/*设置页面的数据获取*/
function get_setPage(){
	var param = {
		"项目名称":$("#project_name").val(),
		"系统编号":$("#sys_num").val(),
		"环路编号":$("#HD_loop").val()+$("#HD_number").val(),
		"布置方式":$("#assign").val(),
		"系统压力":$("#pipe_pressure").val(),
		"管道材料":$("#pipe_material").val(),
		"管道直径":$("#pipe_diameter").val(),
		"管道壁厚":$(".pipe_thick").val(),
		"管系列S值":$(".pipe_s").val(),
		"预览路径":$("#HD_imgSet").attr("src")
	}
	return param;
}
function get_attr(){
	var step = new Array;
	$('input[ name="外墙"]:checked').each(function(i,o){
		step.push(o.value);
	});
	var param ={
		"离墙间距":$("#wall_distance").val(),
		/*"外墙位置":*/
		"外墙位置":step,
		"是否统一":$("#unify").is(":checked"),
		"统一间距":$("#unite").val(),
		"外区间距":$("#HD_out").val(),
		"内区间距":$("#HD_inner").val(),
		"转角半径":$("#corner_radius").val(),
		"回路限长":$("#loop_length").val(),
		"供水管颜色":$("#HD_conduit_pipe_text").val(),
		"回水管颜色":$("#HD_conduit_pipe_text2").val(),
		"铺设方法":$("#lay").val(),
		"地板材料":$("#floor_material").val(),
		"连接方式":$("#connection").val(),
		"固定方式":$("#fixed").val(),
		"备注":$(".HD_beizhu").val()
	}
	return param;
}

/*恢复数据*/
function set_data(param){
	var params = JSON.parse(param);
	$("#project_name").val(params["项目名称"]);
	$("#sys_num").val(params["系统编号"]);
	$("#HD_loop").val(params["系统编号"]+"-");
	/*环路编号*/
	var val = params["环路编号"];
	$("#HD_number").val(val.substring(val.lastIndexOf("-")+1,val.length));
	$("#assign").val(params["布置方式"]);
	$("#pipe_material").val(params["管道材料"]);
	$("#pipe_pressure").val(params["系统压力"]);
	$("#pipe_diameter").val(params["管道直径"]);
	$(".pipe_thick").val(params["管道壁厚"]);
	$(".pipe_s").val(params["管系列S值"]);
	$("#HD_imgSet").attr("src",params["预览路径"]);
}
function attr_data(param){
	var params = JSON.parse(param);
	$("#wall_distance").val(params["离墙间距"]);
	/*外墙位置*/
	$.each(params["外墙位置"],function(){
		var val = this;
		$("input[name='外墙']").each(function(index,obj){
			if(val == obj.value){
				$(obj).attr("checked",true);
			}
		});
	});
	if(params["是否统一"]){
		$("#unify").attr("checked",true);
	}
	unify_click();
	$("#unite").val(params["统一间距"]);
	$("#HD_out").val(params["外区间距"]);
	$("#HD_inner").val(params["内区间距"]);
	$("#corner_radius").val(params["转角半径"]);
	$("#loop_length").val(params["回路线长"]);
	$("#HD_conduit_pipe_text").val(params["供水管颜色"]);
	colorOK(params["供水管颜色"]);
	$("#HD_conduit_pipe_text2").val(params["回水管颜色"]);
	colorOK2(params["回水管颜色"]);
	$("#lay").val(params["铺设方法"]);
	$("#floor_material").val(params["地板材料"]);
	$("#connection").val(params["连接方式"]);
	$("#fixed").val(params["固定方式"]);
	$("#HD_beizhu").val(params["备注"]);
}



