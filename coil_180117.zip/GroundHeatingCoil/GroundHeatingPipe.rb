module GroundHeatingPipe
  class Mycoil
	  def initialize
		# 编码
		@dir = File.dirname(__FILE__).encode("UTF-8")
		@dirname = File.dirname(__FILE__).encode("UTF-8")

		@@dialog = UI::WebDialog.new("地暖盘管工具", true, "机电", 900, 700, 140, 250, true)
		# 导入HTML文件
		@@dialog.set_url (@dirname+"/UI/html/srqSet.html")

		#地暖管属性窗口
		@@dialogDng = UI::WebDialog.new("地暖盘管设置", true, "parme", 576.mm, 115.mm, 150, 150, true)
		@@dialogDng.set_url (@dirname+"/UI/html/index.html")

		#地暖管颜色
		@@dialogColor = UI::WebDialog.new("颜色定义", true, "color", 610.mm, 360.mm, 150, 150, true)
		@@dialogColor.set_url (@dirname+"/UI/html/color.html")

		#关闭窗口触发
		@@dialog.set_on_close {
		  if @@dialog.visible?
			 cancel = "show_aaa()"
			 @@dialog.execute_script(cancel)
		  end
		  # 关闭窗口
		  if @@dialogDng.visible?
			 show_cancel = "show_cancel()"
			 @@dialogDng.execute_script(show_cancel)
		  end
		  if @@dialogColor.visible?
			 @@dialogColor.close
		  end
		}
		#预览框本地图片
		@@dialog.add_action_callback('YL_BD_max') { |dialog, params|
		  # path = File.join(@dir+ "/caizhi/")
		  bd_id = params
		  path = File.join(File.join(MyUI_PATH+"/image/"))
		  dataPath = DFC_BIM::PATH.getPath(:DefaultData, 'Mep', '暖通','管道部分')
		  # puts path
		  if File.exist?(File.join(path, "caizhi"))
			path = File.join(path, "caizhi")
		  end
		  chosen_image = UI.openpanel("选择暖通材质", dataPath, "材质文件|*.jpg;*.png;*.skp;|")
		  if chosen_image
			chosen_image.gsub!('\\', '/')
			productId = File.basename(chosen_image)[0...-4]
			show_image1 = %Q{
						show_YL_image('#{chosen_image}');
					}
			@@dialog.execute_script(show_image1)
		  end
		}

		#地暖管显示小窗口
		@@dialogDng.add_action_callback('mainWin') { |dialogDng, params|
			@@dialog.show{
				aFile = File.new(File.join(@dirname+"/data/set.txt"),"r:UTF-8")
				json = aFile.read
				show_win = "set_data('#{json}')"
				@@dialog.execute_script(show_win)
				#主窗口 带全部属性值
				aFile1 = File.new(File.join(@dirname+"/data/attr.txt"),"r:UTF-8")
				json1 = aFile1.read
				@@dialog.execute_script("attr_value=#{json1}")

			}
			@@dialogDng.close
		}

		@@dialog.add_action_callback('set_back'){|dialog,params|

		}

		@@dialogDng.add_action_callback('attr_back'){|dialog,params|

		}
		@@dialog.add_action_callback('coil_tool'){|dialog,params|
			Sketchup.active_model.select_tool Coil_Tool.new(JSON.parse(params))
		}
		#地暖管显示属性窗口
		@@dialog.add_action_callback('attrSet') { |dialog, params|
			aFile = File.new(File.join(@dirname+"/data/attr.txt"),"r:UTF-8")
			json = aFile.read
			@@dialogDng.show{
				show_win = "attr_data('#{json}')"
				@@dialogDng.execute_script(show_win)
			}
			@@dialog.close
		}

		#地暖管属性界面 参数保存
		@@dialogDng.add_action_callback('save_attr') { |dialogDng, params|
			aFile = File.new(File.join(@dirname + "/data/attr.txt"),"w+")
			if aFile
				aFile.syswrite(params)
			end
			aFile.close
		}

		#地暖管设置界面 参数保存
		@@dialog.add_action_callback('save_Set') { |dialog, params|
			aFile = File.new(File.join(@dirname + "/data/set.txt"),"w+")
			if aFile
				aFile.syswrite(params)
			end
			aFile.close
		}

		@@dialog.add_action_callback('ruby_cancle') { |dialog|
		  dialog.close
		}

		#供水管颜色开启
		@@dialogDng.add_action_callback('ruby_color') { |dialog, params|
			Mycoil.show_color(params)
		}
		@@dialogDng.add_action_callback('ruby_color2') { |dialog, params|
			Mycoil.show_color2(params)
		}
		@@dialogColor.add_action_callback('ruby_changeColor') { |dialog, params|
			show_data = "colorOK('#{params}')"
			@@dialogDng.execute_script(show_data)
		}
		@@dialogColor.add_action_callback('ruby_changeColor2') { |dialog, params|
			show_data = "colorOK2('#{params}')"
			@@dialogDng.execute_script(show_data)
		}
		@@dialogColor.add_action_callback('ruby_colorOK') { |dialogColor, params|
			@@dialogColor.close
		}
		@@dialogColor.add_action_callback('ruby_colorCancel') { |dialog|
			@@dialogColor.close
		}
	 end

	  def self.show()
		if @@dialog == nil

		else
			@@dialog.show
		end
	  end

	  def self.show_color(params)
		@@dialogColor.show {
		  @@dialogColor.set_size(565, 362)
		  show_data = "colorSet('#{params}')"
		  @@dialogColor.execute_script(show_data)
		}
	  end

	  def self.show_color2(params)
		@@dialogColor.show {
		  @@dialogColor.set_size(565, 362)
		  show_data = "colorSet2('#{params}')"
		  @@dialogColor.execute_script(show_data)
		}
	  end

	  def self.show_conduit_pic()
		# show图片
		model = Sketchup.active_model
		attr = model.attribute_dictionary('pic_parameter')
		if attr == nil
		  # puts "默认图片"
		else
		  attr.each { |key, value|
			show_par = "show_update_pic('#{key}','#{value}')"
			@@dialog.execute_script(show_par)
		  }
		end
	  end

  end
end
#load "F:/test/test.rb"
#UI::Dialog.new().show